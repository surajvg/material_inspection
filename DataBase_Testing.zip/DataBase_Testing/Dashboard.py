import dash
from dash import html, dcc, Output, Input, State
import dash_bootstrap_components as dbc
import pandas as pd
import psycopg2
from flask_bcrypt import Bcrypt
import json
from datetime import datetime

# -------------------- DATABASE CONNECTION --------------------
conn = psycopg2.connect(
    host="localhost",
    database="Industry4.0",
    user="postgres",
    password="bel123"

    # drivername="postgresql",
    # username="postgres",
    # password="bel123",   # ⚠️ avoid hardcoding passwords in production
    # host="localhost",
    # port=5432,
    # database="Industry4.0"
)
bcrypt = Bcrypt()

# -------------------- DASH APP --------------------
app = dash.Dash(__name__, suppress_callback_exceptions=True, external_stylesheets=[dbc.themes.BOOTSTRAP])
server = app.server

# -------------------- APP LAYOUT --------------------
app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    dcc.Store(id='current-user', storage_type='session'),  # store logged-in user info
    html.Div(id='page-content')
])

# -------------------- LOGIN PAGE --------------------
login_layout = dbc.Container([
    html.H2("SMT Assembly Line Login"),
    dbc.Input(id='username', placeholder='Username', type='text', className='mb-2'),
    dbc.Input(id='password', placeholder='Password', type='password', className='mb-2'),
    dbc.Button("Login", id='login-btn', color='primary'),
    html.Div(id='login-msg', style={'color':'red', 'marginTop':'10px'})
])

# -------------------- OPERATOR TASK PAGE --------------------
def operator_layout(user_id):
    # Fetch tasks assigned or unassigned but next in sequence
    query = """
    SELECT * FROM tasks
    WHERE (assigned_operator = %s OR assigned_operator IS NULL)
    ORDER BY sequence ASC
    """
    tasks_df = pd.read_sql(query, conn, params=(user_id,))
    
    cards = []
    for _, row in tasks_df.iterrows():
        disable_btn = True
        if row['assigned_operator'] == user_id or (row['assigned_operator'] is None and row['status']=='pending'):
            disable_btn = False
        cards.append(
            dbc.Card([
                dbc.CardBody([
                    html.H5(f"{row['task_name']} (Seq: {row['sequence']})", className="card-title"),
                    html.P(row['description'] or "", className="card-text"),
                    html.P(f"Status: {row['status']}", className="card-text"),
                    dbc.Button("Complete Task", id={'type':'complete-btn','index':row['task_id']}, color='success', disabled=disable_btn)
                ])
            ], className='mb-2')
        )
    
    return dbc.Container([
        html.H2("Your Tasks"),
        html.Hr(),
        html.Div(cards),
        dbc.Button("Logout", id='logout-btn', color='danger', className='mt-3')
    ])

# -------------------- SUPERVISOR DASHBOARD --------------------
def supervisor_layout():
    operators = pd.read_sql("SELECT * FROM users WHERE role='operator'", conn)
    tasks_df = pd.read_sql("SELECT * FROM tasks ORDER BY sequence ASC", conn)
    
    # Operator leave form
    leave_form = dbc.Card([
        dbc.CardBody([
            html.H5("Mark Operator Leave"),
            dbc.Select(id='leave-operator', options=[{'label': row['username'], 'value': row['user_id']} for _, row in operators.iterrows()], placeholder="Select operator"),
            dbc.Input(id='leave-start', type='date', placeholder='Start Date', className='mt-2'),
            dbc.Input(id='leave-end', type='date', placeholder='End Date', className='mt-2'),
            dbc.Button("Submit Leave", id='submit-leave', color='warning', className='mt-2'),
            html.Div(id='leave-msg', style={'color':'green','marginTop':'5px'})
        ])
    ], className='mb-3')
    
    # Tasks table
    task_list = html.Ul([html.Li(f"{row['task_name']} | Status: {row['status']} | Assigned: {row['assigned_operator']}") for _, row in tasks_df.iterrows()])
    
    # Operator list
    operator_list = html.Ul([html.Li(f"{row['username']} - {'Active' if row['is_active'] else 'On Leave'}") for _, row in operators.iterrows()])
    
    return dbc.Container([
        html.H2("Supervisor Dashboard"),
        html.H4("Operators"),
        operator_list,
        leave_form,
        html.H4("Tasks"),
        task_list,
        dbc.Button("Logout", id='logout-btn', color='danger', className='mt-3')
    ])

# -------------------- DYNAMIC TASK ASSIGNMENT --------------------
def assign_next_task(task_id=None):
    cur = conn.cursor()
    
    # Fetch next pending task
    if not task_id:
        cur.execute("""
            SELECT task_id FROM tasks
            WHERE status='pending' AND assigned_operator IS NULL
            ORDER BY sequence ASC
            LIMIT 1
        """)
        result = cur.fetchone()
        if not result:
            return
        task_id = result[0]
    
    # Fetch active operators
    cur.execute("SELECT user_id FROM users WHERE is_active=TRUE AND role='operator'")
    operators = cur.fetchall()
    if not operators:
        print("No active operators available")
        return
    
    # Assign task
    assigned_operator = operators[0][0]
    cur.execute("UPDATE tasks SET assigned_operator=%s WHERE task_id=%s", (assigned_operator, task_id))
    conn.commit()
    cur.close()

# -------------------- OPERATOR LEAVE --------------------
def mark_leave(operator_id, start_date, end_date):
    cur = conn.cursor()
    cur.execute("UPDATE users SET is_active=FALSE WHERE user_id=%s", (operator_id,))
    cur.execute("INSERT INTO leaves (operator_id, start_date, end_date) VALUES (%s,%s,%s)", (operator_id, start_date, end_date))
    
    # Reassign their tasks
    cur.execute("SELECT task_id FROM tasks WHERE assigned_operator=%s AND status != 'completed' ORDER BY sequence ASC", (operator_id,))
    tasks_to_reassign = cur.fetchall()
    for task in tasks_to_reassign:
        assign_next_task(task[0])
    conn.commit()
    cur.close()

# -------------------- PAGE ROUTING --------------------
@app.callback(
    Output('page-content', 'children'),
    Input('url', 'pathname'),
    Input('current-user', 'data')
)
def display_page(pathname, current_user):
    if current_user:
        if current_user['role'] == 'operator':
            return operator_layout(current_user['user_id'])
        elif current_user['role'] == 'supervisor':
            return supervisor_layout()
    return login_layout

# -------------------- LOGIN --------------------
@app.callback(
    Output('current-user', 'data'),
    Output('login-msg', 'children'),
    Input('login-btn', 'n_clicks'),
    State('username', 'value'),
    State('password', 'value'),
    prevent_initial_call=True
)
def login(n, username, password):
    if not username or not password:
        return dash.no_update, "Enter username and password"
    
    cur = conn.cursor()
    cur.execute("SELECT user_id, username, password, role FROM users WHERE username=%s", (username,))
    user = cur.fetchone()
    cur.close()
    
    if user and bcrypt.check_password_hash(user[2], password):
        return {'user_id': user[0], 'username': user[1], 'role': user[3]}, ""
    else:
        return dash.no_update, "Invalid credentials"

# -------------------- COMPLETE TASK --------------------
@app.callback(
    Output('url', 'pathname'),
    Input({'type':'complete-btn','index':dash.dependencies.ALL}, 'n_clicks'),
    State('current-user', 'data'),
    prevent_initial_call=True
)
def complete_task(n_clicks_list, current_user):
    ctx = dash.callback_context
    if not ctx.triggered:
        raise dash.exceptions.PreventUpdate
    button_id = ctx.triggered[0]['prop_id'].split('.')[0]
    task_id = json.loads(button_id)['index']
    
    cur = conn.cursor()
    cur.execute("UPDATE tasks SET status='completed', end_time=NOW() WHERE task_id=%s", (task_id,))
    cur.execute("INSERT INTO task_logs (task_id, operator_id, action) VALUES (%s,%s,%s)", (task_id, current_user['user_id'], 'completed'))
    conn.commit()
    cur.close()
    
    assign_next_task()  # assign next pending task dynamically
    return '/'

# -------------------- SUPERVISOR LEAVE --------------------
@app.callback(
    Output('leave-msg', 'children'),
    Input('submit-leave', 'n_clicks'),
    State('leave-operator', 'value'),
    State('leave-start', 'value'),
    State('leave-end', 'value'),
    prevent_initial_call=True
)
def leave_submit(n, operator_id, start, end):
    if operator_id and start and end:
        mark_leave(operator_id, start, end)
        return "Leave marked and tasks reassigned."
    return "Please fill all fields."

# -------------------- LOGOUT --------------------
@app.callback(
    Output('current-user', 'data'),
    Output('url', 'pathname'),
    Input('logout-btn', 'n_clicks'),
    prevent_initial_call=True
)
def logout(n):
    return None, '/'

# -------------------- RUN SERVER --------------------
if __name__ == '__main__':
    app.run(debug=True)
