from fastapi import FastAPI, Depends,  UploadFile, File,Form
from models import QRRecord,SubContract_Inspection_Report
from datetime import datetime,date,timedelta
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from Database_models import base,Measuring_Instruments_Used,Authorized_Person,DimensionCommonReport,DimensionSample,DimensionType,DimensionReport,LogBook_db,QRRecord_db,QRRecord_Generated,Measuring_Instruments,SubContract_Inspection,MaterialInspectionLot
from Database import session,engine
from typing import Annotated
from fastapi.responses import StreamingResponse
# from io import BytesIO
import io
# from passlib.context import CryptContext

# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# def hash_password(password: str):
#     return pwd_context.hash(password)

app = FastAPI()

# Allow all origins (for dev/testing purposes)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # allow any origin
    allow_credentials=True,
    allow_methods=["*"],  # allow all HTTP methods
    allow_headers=["*"],  # allow all headers
)

base.metadata.create_all(engine)


def init_db():
    db = session()
    try: 
        yield db
    finally:
        db.close()

def Insert_Measurement_Parameters():
    db = next(init_db())

    count = db.query(Measuring_Instruments).count()

    if count == 0:    # only insert once

        instruments = [
            Measuring_Instruments(
                Description="Vernier Calipers",
                Equipment_ID=1,
                Measuring_Accuracy=0.02,
                Make_Model="Mitutoyo CD-6CS",
                Cal_Date=datetime.strptime("10-01-2024", "%d-%m-%Y"),
                Due_Date=datetime.strptime("10-01-2025", "%d-%m-%Y")
            ),
            Measuring_Instruments(
                Description="Scale",
                Equipment_ID=2,
                Measuring_Accuracy=0.03,
                Make_Model="Fisher Scale 150mm",
                Cal_Date=datetime.strptime("15-02-2024", "%d-%m-%Y"),
                Due_Date=datetime.strptime("15-02-2025", "%d-%m-%Y")
            ),
            Measuring_Instruments(
                Description="Tape",
                Equipment_ID=3,
                Measuring_Accuracy=0.01,
                Make_Model="Stanley 3M Tape",
                Cal_Date=datetime.strptime("20-03-2024", "%d-%m-%Y"),
                Due_Date=datetime.strptime("20-03-2025", "%d-%m-%Y")
            ),
        ]

        db.add_all(instruments)
        db.commit()

    db.close()

def seed_dimension_types():
    db = next(init_db())
    count = db.query(DimensionType).count()
    if count==0:
        names = ["Height", "Width", "Length", "Thickness","Resistance","Capacitance","Voltage","Conductance"]
        for name in names:
            exists = db.query(DimensionType).filter_by(Name=name).first()
            if not exists:
                db.add(DimensionType(Name=name))
        db.commit()

def seed_dimension_reports(db, ref_no: str):
    count  = db.query(DimensionReport).filter(DimensionReport.Reference_No==ref_no).count()
    if count == 0:

        types = db.query(DimensionType).all()
        for t in types:

            basic = 50.0  # Example
            tolerance = 0.2

            report = DimensionReport(
                Reference_No=ref_no,
                Dimension_Type_Id=t.Id,
                Basic_Dimension=basic,
                # Measuring_Instr_Id=1,  
                Tolerance=tolerance,
                Min=basic - tolerance,
                Max=basic + tolerance
            )
            db.add(report)
            db.commit()

        # Add 15 empty samples
        # for i in range(1, 16):
        #     sample = DimensionSample(
        #         Report_Id=report.Id,
        #         Sample_No=i,
        #         Value=None,
        #         Status=None
        #     )
        #     db.add(sample)

        # db.commit()

Insert_Measurement_Parameters()
seed_dimension_types()


def initialize_subcontract_entries(db: Session):

    # Fetch all Reference_Nos from QRRecord_Generated
    qr_records = db.query(QRRecord_Generated).all()
    inserted = 0

    # Get last used SAN_NO and Control_No
    last_entry = db.query(SubContract_Inspection).order_by(
        SubContract_Inspection.SAN_NO.desc()
    ).first()

    if last_entry:
        next_san = last_entry.SAN_NO + 1
        next_control = last_entry.Control_No + 1
    else:
        next_san = 1
        next_control = 1000

    for qr in qr_records:

        # Skip if already exists
        exists = db.query(SubContract_Inspection).filter(
            SubContract_Inspection.Reference_No == qr.Reference_No
        ).first()

        if exists:
            continue

        subcontract = SubContract_Inspection(
            Control_No=next_control,
            SAN_NO=next_san,
            Part_No=qr.BEL_Part_Number,
            Description=qr.Description,
            PO_NO=qr.BEL_PO_No,
            Vendor_Name=qr.Vendor_Name,
            Quantity=qr.Quantity,
            Sample="5 Nos",
            Sale_Order="SO-1234",
            Drg_Issue_Level=1,
            Reference_No=qr.Reference_No,
            Date=date.today()
        )

        db.add(subcontract)

        # Increment counters
        next_san += 1
        next_control += 1
        inserted += 1

    db.commit()
    return inserted

# @app.post("/dimension-report/dummy")
# def insert_dummy_dimension_reports(Ref_No:str, db: Session = Depends(init_db)):

#     dummy_inputs = [
#         {"Basic_Dimension": 10.0, "Instrument_Id": 1, "Reference_No": Ref_No},
#         {"Basic_Dimension": 20.0, "Instrument_Id": 2, "Reference_No": Ref_No},
#         {"Basic_Dimension": 30.0, "Instrument_Id": 3, "Reference_No": Ref_No},
#         {"Basic_Dimension": 15.0, "Instrument_Id": 1, "Reference_No": Ref_No},
#         {"Basic_Dimension": 25.0, "Instrument_Id": 2, "Reference_No": Ref_No},
#     ]

#     for item in dummy_inputs:
#         instrument = db.query(Measuring_Instruments).filter(
#             Measuring_Instruments.Id == item["Instrument_Id"]
#         ).first()

#         if not instrument:
#             continue  # skip if missing instrument

#         tolerance = instrument.Measuring_Accuracy

#         report = Dimension_Report(
#             Basic_Dimension=item["Basic_Dimension"],
#             Measuring_Instr_Id=item["Instrument_Id"],
#             Tolerance=tolerance,
#             Min=item["Basic_Dimension"] - tolerance,
#             Max=item["Basic_Dimension"] + tolerance,
#             Reference_No=item["Reference_No"]
#         )

#         db.add(report)

#     db.commit()
#     return {"message": "Dummy dimension reports inserted"}




@app.get("/Instrumentdetails")
def get_details(db:Session = Depends(init_db)):
    db_records = db.query(Measuring_Instruments).all()
    return db_records

@app.get("/details")
def get_details(db:Session = Depends(init_db)):
    db_records = db.query(QRRecord_db).all()
    return db_records

@app.post("/updatedetails")
def add_details(data: dict, db:Session = Depends(init_db)):
    
    # db.add(QRRecord_Generated(**data.model_dump()))

    common_row = QRRecord_Generated(
        # Reference_No=ref_no,
        **data
    )
    db.add(common_row)
    # record = db.query(QRRecord_db).filter_by(QRRecord_db.Reference_No==data.Reference_No).first()
    # if record:
    #     db.delete(record)
    #     # db.commit()
    ref_no = data['Reference_No']
    db.query(QRRecord_db).filter(QRRecord_db.Reference_No == ref_no).delete()
    db.commit()
    added = initialize_subcontract_entries(db)
    return {"message": "added successfully"}

@app.get("/generateddetails")
def get_generated_details(db:Session = Depends(init_db)):
    db_records = db.query(QRRecord_Generated).all()
    return db_records

@app.get("/subcontractinspectionreport")
def get_subcontract_report(Ref_No: str, db: Session = Depends(init_db)):
    seed_dimension_reports(db,Ref_No)
    record = db.query(SubContract_Inspection).filter(
        SubContract_Inspection.Reference_No == Ref_No
    ).first()

    if not record:
        raise HTTPException(
            status_code=404,
            detail=f"No subcontract inspection report found for Reference_No {Ref_No}"
        )

    return record


from fastapi import HTTPException

@app.put("/subcontractinspectionreport")
def update_subcontract_report(
    Ref_No: str,
    updated_data: dict,
    db: Session = Depends(init_db)
):

    # Fetch existing record
    record = db.query(SubContract_Inspection).filter(
        SubContract_Inspection.Reference_No == Ref_No
    ).first()

    if not record:
        raise HTTPException(
            status_code=404,
            detail=f"No subcontract inspection report found for Reference_No {Ref_No}"
        )

    # Update only provided fields
    for field, value in updated_data.items():
        if hasattr(record, field) and value is not None:
            setattr(record, field, value)

    db.commit()
    db.refresh(record)

    return {"message": "Subcontract inspection report updated successfully", "data": record}


# @app.get("/dimensionreport")
# def Get_Dimension_report(Ref_No:str, db: Session = Depends(init_db)):
#     Dimension_records = db.query(Dimension_Report).filter(Dimension_Report.Reference_No==Ref_No).all()
#     return Dimension_records


# @app.put("/dimensionreport")
# def update_dimension_report(
#     Ref_No: str,
#     updated_data: dict,
#     db: Session = Depends(init_db)
# ):

#     # Fetch all matching records
#     records = db.query(Dimension_Report).filter(
#         Dimension_Report.Reference_No == Ref_No
#     ).all()

#     if not records:
#         raise HTTPException(
#             status_code=404,
#             detail=f"No dimension report found for Reference_No {Ref_No}"
#         )

#     # Get list of valid model attributes
#     valid_fields = Dimension_Report.__table__.columns.keys()

#     # Update all records
#     for record in records:
#         for field, value in updated_data.items():
#             if field in valid_fields and value is not None:
#                 setattr(record, field, value)

#     db.commit()

#     return {
#         "message": f"{len(records)} record(s) updated successfully for Reference_No {Ref_No}"
#     }




@app.delete("/delete/all")
def delete_all_tables(db: Session = Depends(init_db)):

    # 1. Delete child table first → SubContract_Inspection
    db.query(SubContract_Inspection).delete()
    db.commit()

    # 2. Delete parent table → QRRecord_Generated
    db.query(QRRecord_Generated).delete()
    db.commit()

    # 3. Delete QRRecord_db (raw QR scanned table)
    db.query(QRRecord_db).delete()
    db.commit()

    # 4. Delete LogBook_db
    db.query(LogBook_db).delete()
    db.commit()

    return {"message": "All QR-related and logbook tables cleared successfully"}


@app.get("/dimensionreport")
def get_dimensions(Ref_No: str, db: Session = Depends(init_db)):

    reports = (
        db.query(DimensionReport)
        .join(DimensionType)
        .filter(DimensionReport.Reference_No == Ref_No)
        .all()
    )

    result = []
    for r in reports:
        result.append({
            "Reference_No":r.Reference_No,
            "Dimension_Report_Id": r.Id,
            "Dimension_Name_Unit": r.dimension_type.Name,
            "Basic_Dimension": r.Basic_Dimension,
            "Tolerance": r.Tolerance,
            "Min": r.Min,
            "Max": r.Max
        })

    return result



# @app.post("/dimensionreport/samples")
# def submit_samples(payload: dict, db: Session = Depends(init_db)):
#     # payload keys: Reference_No, Samples (list)
#     ref = payload.get("ref_no")
#     items = payload.get("sample", [])

#     inserted = 0
#     for item in items:
#         report_id = item.get("report_id")
#         # validate report belongs to the reference (extra safety)
#         report = db.query(DimensionReport).filter(
#             DimensionReport.Id == report_id,
#             DimensionReport.Reference_No == ref
#         ).first()
#         if not report:
#             raise HTTPException(400, f"Report {report_id} not found for reference {ref}")

#         # optionally clear old samples for this report:
#         db.query(DimensionSample).filter(DimensionSample.Report_Id == report_id).delete()

#         # insert new samples
#         for s in item.get("samples", []):
#             sample_row = DimensionSample(
#                 Report_Id=report_id,
#                 Sample_No = int(s["sample_no"]),
#                 Value = float(s["value"]),
#                 Status = "Accepted" if (report.Min <= float(s["value"]) <= report.Max) else "Rejected"

#             )
#             print(sample_row)
#             db.add(sample_row)
#             inserted += 1

#     db.commit()
#     return {"message": "samples saved", "count": inserted}




@app.post("/dimensionreport/samples")
def save_dimension_report(payload: dict, db: Session = Depends(init_db)):

    ref_no = payload["Reference_No"]

    instrument_id = payload.get('Instrument_id',[])
    for id in instrument_id:
        count = db.query(Measuring_Instruments_Used).filter(Measuring_Instruments_Used.Reference_No==ref_no and Measuring_Instruments_Used.Equipment_ID==id).count()
        if count ==0:
            intrument_used = Measuring_Instruments_Used(
                Reference_No = ref_no,
                Equipment_ID = id


            )
            db.add(intrument_used)
            db.commit()
    # 1️⃣ Save COMMON DATA
    common = payload.get("Common", {})
    common_row = DimensionCommonReport(
        Reference_No=ref_no,
        **common
    )
    qr = db.query(DimensionCommonReport).filter(
            DimensionCommonReport.Reference_No == ref_no
        ).first()
    if not qr:
        db.add(common_row)
        db.commit()
    else:
        db.query(DimensionCommonReport).filter(
            DimensionCommonReport.Reference_No == ref_no
        ).delete()
        db.add(common_row)
        db.commit()
        # raise HTTPException(400, "Reference_No already exists")

    # 2️⃣ Save EACH DIMENSION + Samples
    for dim in payload["Dimensions"]:

        # Update or Insert Dimension Report
        report = db.query(DimensionReport).filter(
            DimensionReport.Id == dim["Report_Id"] 
        ).first()

        

        # if not report:
        #     report = DimensionReport(
        #         Id=dim["Report_Id"],
        #         Reference_No=ref_no
        #     )

        # report.Basic_Dimension = dim["Basic_Dimension"]
        # report.Tolerance = dim["Tolerance"]
        # report.Min = dim["Min"]
        # report.Max = dim["Max"]

        # db.add(report)
        # db.commit()

        # Clear old samples
        db.query(DimensionSample).filter(
            DimensionSample.Report_Id == report.Id
        ).delete()
        db.commit()

        # Insert new samples
        for s in dim["Samples"]:
            sample = DimensionSample(
                Report_Id=report.Id,
                Sample_No=s["Sample_No"],
                Value=s["Value"],
                Status=s["Status"],
                Remarks = s['Remarks'],
                Dimension_View_Parameter = s['Dimension_View_Parameter'],
                Dimension_Parameter_Unit = s['Dimension_Parameter_Unit']
            )
            db.add(sample)

        db.commit()

    return {"status": "success", "message": "Dimension data saved successfully"}



@app.post("/intender-report")
def save_intender_report(payload: dict, db: Session = Depends(init_db)):

    try:
        ref_no = payload.get("Reference_No")
        if not ref_no:
            raise HTTPException(400, "Reference_No missing")

        # Check if the reference exists in QRRecord_Generated
        qr = db.query(QRRecord_Generated).filter(
            QRRecord_Generated.Reference_No == ref_no
        ).first()

        if not qr:
            raise HTTPException(
                status_code=404,
                detail=f"Reference_No '{ref_no}' does not exist in QRRecord_Generated"
            )

        # Insert new Intender report entry
        new_entry = Intender_Report(
            Reference_No=ref_no,
            Project_SaleOrder=payload.get("Project_SaleOrder"),
            Result=payload.get("Result"),
            Serial_Numbers=payload.get("Serial_Numbers"),
            Remarks=payload.get("Remarks"),
            Date=datetime.strptime(payload.get("Date"), "%d-%m-%Y")
                if payload.get("Date") else datetime.now(),
            Status=payload.get("Status")
        )

        db.add(new_entry)
        db.commit()
        db.refresh(new_entry)

        return {
            "status": "success",
            "message": "Intender report saved successfully",
            "data": {
                "Id": new_entry.Id,
                "Reference_No": new_entry.Reference_No
            }
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(500, f"Error saving Intender report: {e}")




@app.post("/authorized-person/upload")
async def upload_authorized_person(
    Reference_No: str = Form(...),
    Staff_No: int = Form(...),
    Name: str = Form(...),
    Role: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(init_db)
):

    # Validate reference exists
    ref_exists = db.query(QRRecord_Generated).filter(
        QRRecord_Generated.Reference_No == Reference_No
    ).first()

    if not ref_exists:
        raise HTTPException(status_code=404, detail="Reference_No not found.")

    # Read file binary
    file_bytes = await file.read()

    row = Authorized_Person(
        Reference_No=Reference_No,
        Staff_No=Staff_No,
        Name=Name,
        Role =Role,
        filename=file.filename,
        mimetype=file.content_type,
        data=file_bytes,
        Date=date.today()
    )

    db.add(row)
    db.commit()
    db.refresh(row)

    return {
        "status": "success",
        "id": row.id,
        "filename": row.filename,
        "Reference_No": row.Reference_No
    }




@app.get("/authorized-person/list")
def list_authorized_person(Reference_No: str, db: Session = Depends(init_db)):

    rows = db.query(Authorized_Person).filter(
        Authorized_Person.Reference_No == Reference_No
    ).all()

    if not rows:
        return {"message": "No authorized persons found", "data": []}

    result = []
    for r in rows:
        result.append({
            "id": r.id,
            "Reference_No": r.Reference_No,
            "Name": r.Name,
            "Staff_No": r.Staff_No,
            "Date": r.Date,
            "filename": r.filename,
            "mimetype": r.mimetype
        })

    return {"count": len(result), "data": result}





@app.get("/authorized-person/file/{ref_no}")
def download_authorized_person_file(ref_no: str, db: Session = Depends(init_db)):
    record = db.query(Authorized_Person).filter(Authorized_Person.Reference_No == ref_no).first()

    if not record:
        raise HTTPException(status_code=404, detail="File not found")

    return StreamingResponse(
        io.BytesIO(record.data),
        media_type=record.mimetype,
        headers={"Content-Disposition": f"attachment; filename={record.filename}"}
    )













































    #related for UI Visualization


@app.get("/inspection/full")
def get_full_inspection(Ref_No: str, db: Session = Depends(init_db)):

    # ---------------------------------------------------------
    # 1. QR RECORD
    # ---------------------------------------------------------
    qr = db.query(QRRecord_Generated).filter(
        QRRecord_Generated.Reference_No == Ref_No
    ).first()

    if not qr:
        raise HTTPException(404, f"Reference_No {Ref_No} not found")

    qr_data = {
        "Reference_No": qr.Reference_No,
        "BEL_Part_Number": qr.BEL_Part_Number,
        "Vendor_Name": qr.Vendor_Name,
        "Quantity": qr.Quantity,
        "GR_No": qr.GR_No,
        "Invoice_No": qr.Invoice_No,
        "MPN": qr.MPN,
        "Batch_Lot_No": qr.Batch_Lot_No,
        "DateCode": qr.DateCode,
        "Description": qr.Description,
        "Timestamp": str(qr.Timestamp) if qr.Timestamp else None
    }

    # ---------------------------------------------------------
    # 2. SUBCONTRACT
    # ---------------------------------------------------------
    subcontract = db.query(SubContract_Inspection).filter(
        SubContract_Inspection.Reference_No == Ref_No
    ).first()

    subcontract_data = None
    if subcontract:
        subcontract_data = {
            "SAN_NO": subcontract.SAN_NO,
            "Control_No": subcontract.Control_No,
            "Part_No": subcontract.Part_No,
            "Description": subcontract.Description,
            "PO_NO": subcontract.PO_NO,
            "Vendor_Name": subcontract.Vendor_Name,
            "Quantity": subcontract.Quantity,
            "Sample": subcontract.Sample,
            "Sale_Order": subcontract.Sale_Order,
            "Drg_Issue_Level": subcontract.Drg_Issue_Level,
            "Visual_Inspection": subcontract.Visual_Inspection,
            "Raw_Material_Supplied": subcontract.Raw_Material_Supplied,
            "Raw_Material_Test_Report": subcontract.Raw_Material_Test_Report,
            "Date": str(subcontract.Date) if subcontract.Date else None,
        }

    # ---------------------------------------------------------
    # 3. COMMON DIMENSION REPORT
    # ---------------------------------------------------------
    common = db.query(DimensionCommonReport).filter(
        DimensionCommonReport.Reference_No == Ref_No
    ).first()

    common_data = None
    if common:
        common_data = {
            "Remarks": common.Remarks,
            "Marking_On_Material": common.Marking_On_Material,
            "Dimension_Remark": common.Dimension_Remark,
            "Visual_Inspection_Report": common.Visual_Inspection_Report,
            "Electrical_Inspection_Remark": common.Electrical_Inspection_Remark,
            "Electrical_Parameter": common.Electrical_Parameter,
            "Functional": common.Functional,
            "Dimensions": common.Dimensions,
            "Visual_Inspection": common.Visual_Inspection,
            "COC": common.COC,
            "Test_Reports": common.Test_Reports,
            "Imported_Doc_Received": common.Imported_Doc_Received,
            "Malware_Free_Cert": common.Malware_Free_Cert,
            "FOD_Check": common.FOD_Check,
            "Counterfeit_Checked": common.Counterfeit_Checked,
            "MFG_Date": str(common.MFG_Date) if common.MFG_Date else None,
            "Exp_Date": str(common.Exp_Date) if common.Exp_Date else None,
            "Qty_Received": common.Qty_Received,
            "Qty_Inspected": common.Qty_Inspected,
            "Qty_Accepted": common.Qty_Accepted,
            "Qty_Rejected": common.Qty_Rejected,
            "Inspection_Remarks": common.Inspection_Remarks
        }

    # ---------------------------------------------------------
    # 4. DIMENSIONS + SAMPLES
    # ---------------------------------------------------------
    dimension_rows = (
        db.query(DimensionReport)
        .join(DimensionType, DimensionReport.Dimension_Type_Id == DimensionType.Id)
        .filter(DimensionReport.Reference_No == Ref_No)
        .all()
    )

    dimensions_list = []

    for d in dimension_rows:

        # Convert Measuring Instrument CSV → list[int]
        # if d.Measuring_Instr_Id:
        #     instrument_ids = [int(x) for x in d.Measuring_Instr_Id.split(",")]
        # else:
        instrument_ids = []

        # Fetch samples
        sample_rows = db.query(DimensionSample).filter(
            DimensionSample.Report_Id == d.Id
        ).order_by(DimensionSample.Sample_No).all()

        samples_list = [
            {
                "Id": s.Id,
                "Sample_No": s.Sample_No,
                "Value": s.Value,
                "Status": s.Status,
                "Remarks": s.Remarks,
                "Dimension_View_Parameter": s.Dimension_View_Parameter,
                "Dimension_Parameter_Unit": s.Dimension_Parameter_Unit,
            }
            for s in sample_rows
        ]

        dimensions_list.append({
            "Report_Id": d.Id,
            "Dimension_Type_Id": d.Dimension_Type_Id,
            "Dimension_Name": d.dimension_type.Name,
            "Basic_Dimension": d.Basic_Dimension,
            "Tolerance": d.Tolerance,
            "Min": d.Min,
            "Max": d.Max,
            "Measuring_Instruments": instrument_ids,
            "Samples": samples_list
        })

    # ---------------------------------------------------------
    # FINAL RESPONSE
    # ---------------------------------------------------------
    return {
        "QR_Record": qr_data,
        "SubContract": subcontract_data,
        "Common_Dimension": common_data,
        "Dimensions": dimensions_list
    }

@app.get("/material-inspection/details")
def get_material_inspection_details(db: Session = Depends(init_db)):

    qr_records = db.query(QRRecord_Generated).all()
    response = []

    for qr in qr_records:
        lot = db.query(MaterialInspectionLot).filter(
            MaterialInspectionLot.Reference_No == qr.Reference_No
        ).first()

        response.append({
            # ---------------- GR LIST DATA ----------------
            "SL_No": qr.SL_No,
            "Reference_No": qr.Reference_No,
            "GR_No": qr.GR_No,
            "GR_Date": qr.GR_Date,
            "BEL_Part_Number": qr.BEL_Part_Number,
            "MPN": qr.MPN,
            "Batch_Lot_No": qr.Batch_Lot_No,
            "DateCode": qr.DateCode,
            "Quantity": qr.Quantity,
            "BEL_PO_No": qr.BEL_PO_No,
            "Vendor_Name": qr.Vendor_Name,
            "OEM_Make": qr.OEM_Make,
            "Manufacturing_Place": qr.Manufacturing_Place,

            # ---------------- PART A DATA ----------------
            "Inspection_Lot_Information": {
                "inspectionLotNumber": lot.Inspection_Lot_Number if lot else "",
                "description": lot.Description if lot else "",
                "revisionLevel": lot.Revision_Level if lot else "",
                "valuationType": lot.Valuation_Type if lot else "",
                "storageLocation": lot.Storage_Location if lot else "",
                "saleOrderNumber": lot.Sale_Order_Number if lot else "",
                "project": lot.Project if lot else "",
                "plant": lot.Plant if lot else "",
                "purchaseOrderNumber": lot.PO_Number if lot else "",
                "grNumber": lot.GR_Number if lot else qr.GR_No,
                "grPostingDate": lot.GR_Posting_Date if lot else qr.GR_Date,
                "vendor": lot.Vendor_Name if lot else qr.Vendor_Name,
                "inspectionStartDate": lot.Inspection_Start_Date if lot else None,
                "inspectionEndDate": lot.Inspection_End_Date if lot else None,
            }
        })

    return response
