from sqlalchemy import Column,Integer,String,Float,DateTime,ForeignKey,Date,LargeBinary
# from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import date
# New, future-proof import for SQLAlchemy 2.0+
from sqlalchemy.orm import declarative_base


base  = declarative_base()
class QRRecord_db(base):
    __tablename__ = "qr_records"
    Timestamp = Column(DateTime)
    SL_No = Column(Integer, autoincrement=True) 
    BEL_Part_Number = Column(String)
    MPN= Column(String)
    Batch_Lot_No= Column(String)
    DateCode= Column(String)
    Quantity= Column(String)
    BEL_PO_No= Column(String)
    Vendor_Name= Column(String)
    OEM_Make= Column(String)
    Manufacturing_Place= Column(String)
    GR_No= Column(String)
    GR_Date= Column(DateTime)
    Reference_No= Column(String, primary_key = True, index=True)
    Description = Column(String)
    Vendor_Code = Column(String)
    Invoice_No  = Column(String)
    Invoice_Dt = Column(DateTime)

class LogBook_db(base):
    __tablename__ = "log_book"
    
    SL_No = Column(Integer, primary_key=True, autoincrement=True, index=True)
    Timestamp = Column(DateTime)
    BEL_Part_Number = Column(String)
    MPN = Column(String)
    Batch_Lot_No = Column(String)
    DateCode = Column(String)
    Quantity = Column(String)
    BEL_PO_No = Column(String)
    Vendor_Name = Column(String)
    OEM_Make = Column(String)
    Manufacturing_Place = Column(String)





class QRRecord_Generated(base):
    __tablename__ = "generated_qr_records"
    Timestamp = Column(DateTime)
    SL_No = Column(Integer) 
    BEL_Part_Number = Column(String)
    MPN= Column(String)
    Batch_Lot_No= Column(String)
    DateCode= Column(String)
    Quantity= Column(String)
    BEL_PO_No= Column(String)
    Vendor_Name= Column(String)
    OEM_Make= Column(String)
    Manufacturing_Place= Column(String)
    GR_No= Column(String)
    GR_Date= Column(DateTime)
    Reference_No= Column(String, primary_key = True, index=True)
    Description = Column(String)
    Vendor_Code = Column(String)
    Invoice_No  = Column(String)
    Invoice_Dt = Column(DateTime)
    Status = Column(String)

    subcontracts = relationship("SubContract_Inspection", back_populates="qr_record", cascade="all, delete-orphan")
    dimensions = relationship("DimensionReport", back_populates="qr_record",cascade="all, delete-orphan")
    dimension_common_reports = relationship("DimensionCommonReport", back_populates="reference", cascade="all, delete-orphan")
    intender_report = relationship("Intender_Report", back_populates="qr_record",cascade="all, delete-orphan")
    Submission_Details = relationship("Authorized_Person", back_populates="qr_record",cascade="all, delete-orphan")
    instrument = relationship("Measuring_Instruments_Used", back_populates="qr_record",cascade="all, delete-orphan")



    
class DimensionInstrumentMap(base):
    __tablename__ = "dimension_instrument_map"

    Id = Column(Integer, primary_key=True, index=True)

    Report_Id = Column(Integer, ForeignKey("dimension_reports.Id"))
    Instrument_Id = Column(Integer, ForeignKey("measuring_instruments.Equipment_ID"))

    # Relationships
    report = relationship("DimensionReport", back_populates="instrument_links")
    instrument = relationship("Measuring_Instruments", back_populates="report_links")

class Measuring_Instruments(base):
    __tablename__ = "measuring_instruments"

    Description = Column(String)
    Equipment_ID = Column(Integer, primary_key=True, index=True)
    Measuring_Accuracy = Column(Float)
    Make_Model = Column(String)
    Cal_Date = Column(DateTime)
    Due_Date = Column(DateTime)

    report_links = relationship(
        "DimensionInstrumentMap",
        back_populates="instrument",
        cascade="all, delete-orphan"
    )
    instruments = relationship(
        "Measuring_Instruments_Used",
        back_populates="instrument_used",
        cascade="all, delete-orphan"
    )

class SubContract_Inspection(base):
    __tablename__ = "subcontract_inspection"

    SAN_NO = Column(Integer, primary_key=True, index=True)
    Control_No = Column(Integer)

    # Basic details (common in both tables)
    Part_No = Column(String)
    Description = Column(String)
    PO_NO = Column(String)
    Vendor_Name = Column(String)
    Quantity = Column(String)
    Sample = Column(String)
    Sale_Order = Column(String)
    Drg_Issue_Level = Column(Integer)

    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))
    Date = Column(Date, default=date.today)

    # Report section (only in second table)
    Vendor_Dimension_Report = Column(String, nullable=True)
    Visual_Inspection = Column(String, nullable=True)
    Raw_Material_Supplied = Column(String, nullable=True)
    Raw_Material_Test_Report = Column(String, nullable=True)
    # Relationship
    qr_record = relationship("QRRecord_Generated", back_populates="subcontracts")

# class Dimension_Report(base):
#     __tablename__ = "dimension_report"
#     id = Column(Integer,primary_key=True,index=True)
#     Basic_Dimension = Column(Float)
#     Measuring_Instr_Id = Column(Integer, ForeignKey("measuring_instruments.Id"))
#     Tolerance = Column(Float)
#     Min = Column(Float)
#     Max = Column(Float)
#     Sample_1 = Column(Float,nullable=True)
#     Sample_2 = Column(Float,nullable=True)
#     Sample_3 = Column(Float,nullable=True)
#     Sample_4 = Column(Float,nullable=True)
#     Sample_5 = Column(Float,nullable=True)
#     Sample_6= Column(Float,nullable=True)
#     Sample_7 = Column(Float,nullable=True)
#     Sample_8 = Column(Float,nullable=True)
#     Sample_9 = Column(Float,nullable=True)
#     Sample_10 = Column(Float,nullable=True)
#     Sample_11 = Column(Float,nullable=True)
#     Sample_12 = Column(Float,nullable=True)
#     Sample_13 = Column(Float,nullable=True)
#     Sample_14 = Column(Float,nullable=True)
#     Sample_15 = Column(Float,nullable=True)

#     Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))
#     qr_record = relationship("QRRecord_Generated", back_populates="dimensions")
#     measurement = relationship("Measuring_Instruments", back_populates="dimension")



class DimensionType(base):
    __tablename__ = "dimension_types"

    Id = Column(Integer, primary_key=True, index=True)
    Name = Column(String, nullable=False)

    reports = relationship("DimensionReport", back_populates="dimension_type")
    

# -------------------------------
# 2. Dimension Report (Per Dimension Per Reference_No)
# -------------------------------
class DimensionReport(base):
    __tablename__ = "dimension_reports"

    Id = Column(Integer, primary_key=True, index=True)
    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))
    Dimension_Type_Id = Column(Integer, ForeignKey("dimension_types.Id"))

    Basic_Dimension = Column(Float)
    Tolerance = Column(Float)
    Min = Column(Float)
    Max = Column(Float)

    dimension_type = relationship("DimensionType", back_populates="reports")
    qr_record = relationship("QRRecord_Generated", back_populates="dimensions")

    samples = relationship("DimensionSample", back_populates="report",
                           cascade="all, delete-orphan")

    instrument_links = relationship(
        "DimensionInstrumentMap",
        back_populates="report",
        cascade="all, delete-orphan"
    )


# -------------------------------
# 3. Dimension Samples (Values Entered by User)
# -------------------------------
class DimensionSample(base):
    __tablename__ = "dimension_samples"

    Id = Column(Integer, primary_key=True, index=True)
    Report_Id = Column(Integer, ForeignKey("dimension_reports.Id"))
    Sample_No = Column(Integer)  # 1 to 15
    Value = Column(Float)
    Status = Column(String)  # OK / NOT OK
    Remarks = Column(String,nullable=True)
    Dimension_View_Parameter = Column(String,nullable=True)
    Dimension_Parameter_Unit = Column(String)
    
    report = relationship("DimensionReport", back_populates="samples")


class DimensionCommonReport(base):
    __tablename__ = "dimension_common_report"

    Id = Column(Integer, primary_key=True, index=True)
    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))

    
    Remarks = Column(String, nullable=True)
    Marking_On_Material = Column(String, nullable=True)
    Dimension_Remark = Column(String, nullable=True)
    Visual_Inspection_Report = Column(String, nullable=True)
    Electrical_Inspection_Remark = Column(String, nullable=True)
    Electrical_Parameter = Column(String, nullable=True)
    Functional = Column(String, nullable=True)
    Dimensions = Column(String, nullable=True)
    Visual_Inspection = Column(String, nullable=True)
    COC = Column(String, nullable=True)
    Test_Reports = Column(String, nullable=True)
    Imported_Doc_Received = Column(String, nullable=True)
    Malware_Free_Cert = Column(String, nullable=True)
    FOD_Check = Column(String, nullable=True)
    Counterfeit_Checked = Column(String, nullable=True)
    MFG_Date = Column(Date, nullable=True)
    Exp_Date = Column(Date, nullable=True)
    Qty_Received = Column(String, nullable=True)
    Qty_Inspected = Column(String, nullable=True)
    Qty_Accepted = Column(String, nullable=True)
    Qty_Rejected = Column(String, nullable=True)
    Inspection_Remarks = Column(String, nullable=True)

    # Links all DimensionReports for this reference
    reference = relationship("QRRecord_Generated", back_populates="dimension_common_reports")










class Intender_Report(base):
    __tablename__ = "intender_report"

    Id = Column(Integer, primary_key=True, index=True)
    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))
    Project_SaleOrder = Column(String)  # 1 to 15
    Result = Column(String)
    Serial_Numbers = Column(String)  # OK / NOT OK
    Remarks = Column(String)
    Date = Column(DateTime)
    Status = Column(String)
    
    qr_record = relationship("QRRecord_Generated", back_populates="intender_report")



class Authorized_Person(base):
    __tablename__ = 'user_data'
    
    id = Column(Integer, primary_key=True)
    filename = Column(String)
    mimetype = Column(String)
    data = Column(LargeBinary)
    Staff_No = Column(Integer)
    Name = Column(String)
    Role = Column(String)
    Date = Column(Date,default=date.today)
    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))
    qr_record = relationship("QRRecord_Generated", back_populates="Submission_Details")


class Measuring_Instruments_Used(base):
    __tablename__ = "measuring_instrument_used"

    id = Column(Integer,primary_key=True)
    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))
    Equipment_ID = Column(Integer, ForeignKey("measuring_instruments.Equipment_ID"))

    qr_record = relationship("QRRecord_Generated", back_populates="instrument")
    instrument_used = relationship(
        "Measuring_Instruments",
        back_populates="instruments"
    )


# {
#   "Reference_No": "REF001",
#   "Samples": [
#     {
#       "Report_Id": 10,
#       "Dimension": "Height",
#       "Samples": [
#          {"Sample_No":1, "Value": 10.02},
#          {"Sample_No":2, "Value": 10.00},
#          ...
#          {"Sample_No":15, "Value": 9.99}
#       ]
#     },
#     {
#       "Report_Id": 11,
#       "Dimension": "Width",
#       "Samples": [
#          {"Sample_No":1, "Value": 20.01},
#          ...
#       ]
#     }
#   ]
# }



# {
#   "Reference_No": "REF001",

#   "Common": {
#      "Dimension_Parameter": "Mechanical Size",
#      "Unit": "mm",
#      "Remarks": "Overall good",
#      "Marking_On_Material": "Laser-etched",
#      "Visual_Inspection": "OK",
#      "COC": "Provided",
#      "Test_Reports": "Available",
#      "Qty_Received": "100",
#      "Qty_Inspected": "15",
#      "Qty_Accepted": "15",
#      "Inspection_Remarks": "All good"
#   },

#   "Dimensions": [
#     {
#       "Report_Id": 10,
#       "Dimension_Name": "Height",
#       "Basic_Dimension": 50.0,
#       "Tolerance": 0.5,
#       "Min": 49.5,
#       "Max": 50.5,
#       "Samples": [
#         {"Sample_No": 1, "Value": 50.02, "Status": "OK"},
#         {"Sample_No": 2, "Value": 49.98, "Status": "OK"},
#         {"Sample_No": 3, "Value": 49.30, "Status": "NOT OK"}
#       ]
#     },

#     {
#       "Report_Id": 11,
#       "Dimension_Name": "Width",
#       "Basic_Dimension": 30.0,
#       "Tolerance": 0.2,
#       "Min": 29.8,
#       "Max": 30.2,
#       "Samples": [
#         {"Sample_No": 1, "Value": 30.00, "Status": "OK"},
#         {"Sample_No": 2, "Value": 30.10, "Status": "OK"}
#       ]
#     }
#   ]
# }


# =====================================================
# MATERIAL INSPECTION MODELS
# =====================================================

class MaterialInspectionHeader(base):
    __tablename__ = "material_inspection_header"

    Id = Column(Integer, primary_key=True, index=True)
    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"))

    Inspection_Lot_Number = Column(String)
    Material_Number = Column(String)
    Revision_Level = Column(String)
    Valuation_Type = Column(String)
    Storage_Location = Column(String)
    Sale_Order_Number = Column(String)
    Project = Column(String)
    Plant = Column(String)
    Purchase_Order_Number = Column(String)
    GR_Number = Column(String)
    GR_Posting_Date = Column(Date)
    Vendor = Column(String)
    Inspection_Start_Date = Column(Date)
    Inspection_End_Date = Column(Date)

    qr_record = relationship("QRRecord_Generated")
    lines = relationship(
        "MaterialInspectionLine",
        back_populates="header",
        cascade="all, delete-orphan"
    )


class MaterialInspectionLine(base):
    __tablename__ = "material_inspection_line"

    Id = Column(Integer, primary_key=True, index=True)
    Header_Id = Column(Integer, ForeignKey("material_inspection_header.Id"))

    Section_Code = Column(String)   # 0010 / 0020 / 0030
    MIC_No = Column(String)
    MIC = Column(String)
    MIC_Desc = Column(String)
    Sampling_Procedure = Column(String)
    Sample_Qty = Column(String)
    Inspected_Qty = Column(String)
    UOM = Column(String)
    Target_UOM = Column(String)
    Lower_Limit = Column(String)
    Upper_Limit = Column(String)
    Sample_No = Column(String)
    Result = Column(String)
    Valuation = Column(String)
    Inspection_Description = Column(String)

    header = relationship("MaterialInspectionHeader", back_populates="lines")

class MaterialInspectionLot(base):
    __tablename__ = "material_inspection_lot"

    Id = Column(Integer, primary_key=True, index=True)
    Reference_No = Column(String, ForeignKey("generated_qr_records.Reference_No"), unique=True)

    Inspection_Lot_Number = Column(String)
    Description = Column(String)
    Revision_Level = Column(String)
    Valuation_Type = Column(String)
    Storage_Location = Column(String)
    Sale_Order_Number = Column(String)
    Project = Column(String)
    Plant = Column(String)
    PO_Number = Column(String)
    GR_Number = Column(String)
    GR_Posting_Date = Column(Date)
    Vendor_Name = Column(String)
    Inspection_Start_Date = Column(Date)
    Inspection_End_Date = Column(Date)

    qr_record = relationship("QRRecord_Generated")
