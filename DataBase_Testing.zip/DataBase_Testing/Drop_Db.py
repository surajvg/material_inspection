from sqlalchemy import create_engine, MetaData
from sqlalchemy.engine import URL

db_url = URL.create(
    drivername="postgresql",
    username="postgres",
    password="bel123",   # ⚠️ avoid hardcoding passwords in production
    host="localhost",
    port=5432,
    database="Industry4.0"
)
engine = create_engine(db_url)

meta = MetaData()
meta.reflect(bind=engine)
meta.drop_all(bind=engine)

print("All tables dropped successfully!")

