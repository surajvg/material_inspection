import cv2
from pyzbar import pyzbar
import pandas as pd
from datetime import datetime
import os, hashlib, re
from flask import Flask, Response
import dash
from dash import dash_table, html, dcc, Input, Output
import dash_bootstrap_components as dbc

from sqlalchemy.orm import Session
from Data_Server import init_db
from Database_models import QRRecord_db as DB_QRRecord, QRRecord_Generated,LogBook_db
from dash import Dash, html, dcc
from dash import Input, Output, State

latest_qr_data = None

duplicate_alert_msg = ""
duplicate_alert_time = None
# ==============================
# Configuration
# ==============================
CSV_FILE = "qr_log_parsed.csv"
COLUMNS = [
    "Timestamp", "SL_No", "BEL_Part_Number", "MPN", "Batch_Lot_No",
    "DateCode", "Quantity", "BEL_PO_No", "Vendor_Name", "OEM_Make",
    "Manufacturing_Place", "GR_No", "GR_Date", "Reference_No","Description", "Vendor_Code",
    "Invoice_No",
    "Invoice_Dt"
]
COLUMNS_Log_Book = [
    "Timestamp", "SL_No", "BEL_Part_Number", "MPN", "Batch_Lot_No",
    "DateCode", "Quantity", "BEL_PO_No", "Vendor_Name", "OEM_Make",
    "Manufacturing_Place",]

def load_from_db_live():
    """Fetch all QR records from the database."""
    try:
        db = next(init_db())
        records = db.query(DB_QRRecord).all()
        if not records:
            # Return empty dataframe with predefined columns
            return pd.DataFrame(columns=COLUMNS)

        df = pd.DataFrame([{
            "Timestamp": r.Timestamp.strftime("%Y-%m-%d %H:%M:%S") if r.Timestamp else "",
            "SL_No": r.SL_No,
            "BEL_Part_Number": r.BEL_Part_Number,
            "MPN": r.MPN,
            "Batch_Lot_No": r.Batch_Lot_No,
            "DateCode": r.DateCode,
            "Quantity": r.Quantity,
            "BEL_PO_No": r.BEL_PO_No,
            "Vendor_Name": r.Vendor_Name,
            "OEM_Make": r.OEM_Make,
            "Manufacturing_Place": r.Manufacturing_Place,
            "GR_No": r.GR_No,
            "GR_Date": r.GR_Date.strftime("%Y-%m-%d") if r.GR_Date else "",
            "Reference_No": r.Reference_No,
            "Description": r.Description,
            "Vendor_Code": r.Vendor_Code,
            "Invoice_No": r.Invoice_No,
            "Invoice_Dt": r.Invoice_Dt
        } for r in records])

        # Ensure all expected columns exist
        for col in COLUMNS:
            if col not in df.columns:
                df[col] = ""

        return df[COLUMNS]

    except Exception as e:
        print("❌ Database read failed:", e)
        return pd.DataFrame(columns=COLUMNS)
    finally:
        db.close()

def load_from_db():
    """Fetch all QR records from the database."""
    try:
        db = next(init_db())
        records = db.query(QRRecord_Generated).all()
        if not records:
            # Return empty dataframe with predefined columns
            return pd.DataFrame(columns=COLUMNS)

        df = pd.DataFrame([{
            "Timestamp": r.Timestamp.strftime("%Y-%m-%d %H:%M:%S") if r.Timestamp else "",
            "SL_No": r.SL_No,
            "BEL_Part_Number": r.BEL_Part_Number,
            "MPN": r.MPN,
            "Batch_Lot_No": r.Batch_Lot_No,
            "DateCode": r.DateCode,
            "Quantity": r.Quantity,
            "BEL_PO_No": r.BEL_PO_No,
            "Vendor_Name": r.Vendor_Name,
            "OEM_Make": r.OEM_Make,
            "Manufacturing_Place": r.Manufacturing_Place,
            "GR_No": r.GR_No,
            "GR_Date": r.GR_Date.strftime("%Y-%m-%d") if r.GR_Date else "",
            "Reference_No": r.Reference_No,
            "Description": r.Description,
            "Vendor_Code": r.Vendor_Code,
            "Invoice_No": r.Invoice_No,
            "Invoice_Dt": r.Invoice_Dt
        } for r in records])

        # Ensure all expected columns exist
        for col in COLUMNS:
            if col not in df.columns:
                df[col] = ""

        return df[COLUMNS]

    except Exception as e:
        print("❌ Database read failed:", e)
        return pd.DataFrame(columns=COLUMNS)
    finally:
        db.close()

df = load_from_db()

def load_from_log_book():
    """Fetch all QR records from the database."""
    try:
        db = next(init_db())
        records = db.query(LogBook_db).all()
        if not records:
            # Return empty dataframe with predefined columns
            return pd.DataFrame(columns=COLUMNS_Log_Book)

        df = pd.DataFrame([{
            "Timestamp": r.Timestamp.strftime("%Y-%m-%d %H:%M:%S") if r.Timestamp else "",
            "SL_No": r.SL_No,
            "BEL_Part_Number": r.BEL_Part_Number,
            "MPN": r.MPN,
            "Batch_Lot_No": r.Batch_Lot_No,
            "DateCode": r.DateCode,
            "Quantity": r.Quantity,
            "BEL_PO_No": r.BEL_PO_No,
            "Vendor_Name": r.Vendor_Name,
            "OEM_Make": r.OEM_Make,
            "Manufacturing_Place": r.Manufacturing_Place,
            
        } for r in records])

        # Ensure all expected columns exist
        for col in COLUMNS_Log_Book:
            if col not in df.columns:
                df[col] = ""

        return df[COLUMNS_Log_Book]

    except Exception as e:
        print("❌ Database read failed:", e)
        return pd.DataFrame(columns=COLUMNS_Log_Book)
    finally:
        db.close()

df_Log_Book = load_from_log_book()
# ==============================
# Utility & Hashing
# ==============================
def clean_text(value: str) -> str:
    """Remove spaces and symbols, keep only letters/numbers."""
    if not isinstance(value, str):
        value = str(value)
    return re.sub(r"[^A-Za-z0-9]", "", value).upper()

def hash_32bit(input_str: str) -> str:
    """Return uppercase 8-char (32-bit) hex hash."""
    return hashlib.md5(input_str.encode()).hexdigest()[:8].upper()

# def row_hash(row):
#     """Row hash to detect duplicates (ignores timestamps and GR/Ref)."""
#     relevant_cols = [c for c in COLUMNS if c not in ["Timestamp", "GR_No", "GR_Date", "Reference_No", "SL_No"]]
#     return hashlib.md5("_".join(str(row[c]) for c in relevant_cols).encode()).hexdigest()
def row_hash(row):
    """
    Generate a 32-bit hash for duplicate detection.
    - Considers only alphanumeric characters (A–Z, 0–9)
    - Ignores case, spaces, punctuation, and non-key columns
    """
    relevant_cols = [
        c for c in COLUMNS 
        if c not in ["Timestamp", "GR_No", "GR_Date", "Reference_No", "SL_No"]
    ]

    concat_str = ""
    for c in relevant_cols:
        val = str(row.get(c, ""))
        val = re.sub(r"[^A-Za-z0-9]", "", val).upper()  # keep only alphanumeric
        concat_str += val + "_"

    return hashlib.md5(concat_str.encode()).hexdigest()

# ==============================
# GR Number (32-bit hash)
# ==============================
def generate_gr_no(parsed):
    """Generate a deterministic GR_No based on key fields."""
    base_key = (
        clean_text(parsed.get("BEL_PO_No", "")) +
        clean_text(parsed.get("BEL_Part_Number", "")) +
        clean_text(parsed.get("Batch_Lot_No", "")) +
        clean_text(parsed.get("DateCode", "")) +
        clean_text(parsed.get("Vendor_Name", ""))
    )
    return hash_32bit(base_key)

# ==============================
# Optimized Reference Number Generator
# ==============================
existing_refs = {}  # Memory cache for Reference_No versioning

def generate_reference_no(parsed):
    """
    Generate a stable 32-bit Reference_No with version suffixes.
    - If new PO+Part → new hash.
    - If same combo and fields unchanged → reuse.
    - If changed → append _1, _2, etc.
    """
    po = parsed.get("Vendor_Name", "")
    part = parsed.get("BEL_Part_Number", "")
    key_pair = (po, part)
    compare_fields = ["Quantity", "Batch_Lot_No", "DateCode", "BEL_PO_No"]

    # If first time for this PO+Part combo
    if key_pair not in existing_refs:
        key = (
            clean_text(po)
            + clean_text(part)
            + clean_text(parsed.get("BEL_PO_No", ""))
            + clean_text(parsed.get("Quantity", ""))
            + clean_text(parsed.get("Batch_Lot_No", ""))
            + clean_text(parsed.get("DateCode", ""))
        )
        base_ref = hash_32bit(key)
        existing_refs[key_pair] = {
            "last_fields": {f: parsed.get(f, "") for f in compare_fields},
            "base_ref": base_ref,
            "suffix_count": 0,
        }
        return base_ref
    print("key_pair")
    # Compare current to last recorded fields
    record = existing_refs[key_pair]
    changed = any(
        clean_text(record["last_fields"].get(f, "")) != clean_text(parsed.get(f, ""))
        for f in compare_fields
    )
    print("changed",changed)
    if not changed:
        return (
            f"{record['base_ref']}_{record['suffix_count']}"
            if record["suffix_count"] > 0
            else record["base_ref"]
        )

    # If changed → increment suffix

    record["suffix_count"] += 1
    print(record["suffix_count"])
    record["last_fields"] = {f: parsed.get(f, "") for f in compare_fields}
    print(f"{record['base_ref']}_{record['suffix_count']}")
    return f"{record['base_ref']}_{record['suffix_count']}"

# ==============================
# QR Parsing
# ==============================
def parse_qr_data(qr_text):
    data = {col: "" for col in COLUMNS}
    data["Timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    for line in qr_text.splitlines():
        if ":" in line:
            key, value = line.split(":", 1)
            key = key.strip().lower().replace(" ", "")
            value = value.strip()
            if "belpartnumber" in key: data["BEL_Part_Number"] = value
            elif "mpn" in key: data["MPN"] = value
            elif "batch/lotno" in key: data["Batch_Lot_No"] = value
            elif "datecode" in key: data["DateCode"] = value
            elif "quantity" in key: data["Quantity"] = value
            elif "belpono" in key: data["BEL_PO_No"] = value
            elif "vendorname" in key: data["Vendor_Name"] = value
            elif "oem/make" in key: data["OEM_Make"] = value
            elif "manufacturingplace" in key: data["Manufacturing_Place"] = value
    return data



def save_logbook(parsed):
    try:
        db = next(init_db())
                
        db_record = LogBook_db(
            Timestamp=datetime.now(),
            BEL_Part_Number=parsed["BEL_Part_Number"],
            MPN=parsed["MPN"],
            Batch_Lot_No=parsed["Batch_Lot_No"],
            DateCode=parsed["DateCode"],
            Quantity=parsed["Quantity"],
            BEL_PO_No=parsed["BEL_PO_No"],
            Vendor_Name=parsed["Vendor_Name"],
            OEM_Make=parsed["OEM_Make"],
            Manufacturing_Place=parsed["Manufacturing_Place"],
        )
        db.add(db_record)
        db.commit()
    except Exception as e:
                print("❌ Database insert failed:", e)
    finally:
        db.close()
# ==============================
# Camera + QR Reader
# ==============================
camera = cv2.VideoCapture(0)

def generate_frames():
    """Continuously read from camera and process QR codes."""
    global parsed, latest_qr_data
    while True:
        success, frame = camera.read()
        if not success:
            continue

        qr_codes = pyzbar.decode(frame)
        display_frame = frame.copy()

        df_existing = load_from_log_book()
        existing_hashes = set(row_hash(r) for _, r in df_existing.iterrows())
        
        for qr in qr_codes:
            qr_text = qr.data.decode("utf-8").strip()
            
            parsed = parse_qr_data(qr_text)
            
                

            if all(v == "" for k, v in parsed.items() if k != "Timestamp"):
                continue
            from datetime import datetime
            global duplicate_alert_msg, duplicate_alert_time
            current_hash = row_hash(parsed)
            if current_hash in existing_hashes:
                duplicate_alert_msg = "⚠️ Duplicate QR Detected!"
                duplicate_alert_time = datetime.now()
                print("⚠️ Duplicate QR ignored.")
                continue
            else:
                duplicate_alert_msg = ""
                duplicate_alert_time = None
            
            parsed["SL_No"] = str(len(df_existing) + 1)
            parsed["GR_No"] = generate_gr_no(parsed)
            parsed["GR_Date"] = datetime.now().strftime("%Y-%m-%d")
            parsed["Reference_No"] = generate_reference_no(parsed)
            latest_qr_data = parsed
            # Append to CSV
            pd.DataFrame([parsed]).to_csv(CSV_FILE, mode="a", index=False, header=False)
            existing_hashes.add(current_hash)
            save_logbook(latest_qr_data)
            
            
            # Draw QR bounding box
            x, y, w, h = qr.rect
            cv2.rectangle(display_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(display_frame, f"SL:{parsed['SL_No']}", (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        _, buffer = cv2.imencode(".jpg", display_frame)
        yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + buffer.tobytes() + b"\r\n")

# ==============================
# Flask + Dash
# ==============================
server = Flask(__name__)

@server.route("/video_feed")
def video_feed():
    return Response(generate_frames(), mimetype="multipart/x-mixed-replace; boundary=frame")

app = dash.Dash(__name__, server=server, external_stylesheets=[dbc.themes.LITERA])
app.title = "SAP Data Entry - QR Scanner"
data_Live = load_from_db_live()


app.layout = dbc.Container([

    # =======================
    # Header
    # =======================
    dbc.Row([
        dbc.Col([
            html.H2(
                "SAP Data Entry Automation – GR/Reference Generator",
                className="text-center my-4 fw-bold",
                style={"color": "#1f2937"}
            )
        ])
    ]),

    # =======================
    # Duplicate Alert Banner
    # =======================
    html.Div(
        id="duplicate_alert",
        style={
            "color": "white",
            "backgroundColor": "#d9534f",
            "padding": "12px",
            "textAlign": "center",
            "fontWeight": "bold",
            "display": "none",
            "borderRadius": "6px",
            "marginBottom": "15px",
            "boxShadow": "0px 2px 6px rgba(0,0,0,0.2)"
        },
    ),

   

    # =======================
    # Input Forms Section
    # =======================
    dbc.Card([
        dbc.CardHeader(
            "QR Data (Auto-Filled) & Manual Entry",
            className="fw-bold",
            style={"backgroundColor": "#1f2937", "color": "white",'text-align':'center'}
        ),

        dbc.CardBody([
            dbc.Row([

                # Auto QR Fields (Label + Span for Data)
                dbc.Col([
                    html.H5("Scanned QR Data", className="fw-bold text-primary mb-3"),

                    dbc.Row([
                        dbc.Col(html.Label("BEL Part Number:", className="fw-bold"), width=5),
                        dbc.Col(html.Span(id="bel_display", className="text-muted"), width=7)
                    ], className="mb-3 border-bottom"), # Added spacing and separator

                    dbc.Row([
                        dbc.Col(html.Label("MPN:", className="fw-bold"), width=5),
                        dbc.Col(html.Span(id="mpn_display", className="text-muted"), width=7)
                    ], className="mb-3 border-bottom"),

                    dbc.Row([
                        dbc.Col(html.Label("Batch/Lot No:", className="fw-bold"), width=5),
                        dbc.Col(html.Span(id="batch_display", className="text-muted"), width=7)
                    ], className="mb-3 border-bottom"),

                    dbc.Row([
                        dbc.Col(html.Label("Date Code:", className="fw-bold"), width=5),
                        dbc.Col(html.Span(id="dc_display", className="text-muted"), width=7)
                    ], className="mb-3 border-bottom"),
                    
                    dbc.Row([
                        dbc.Col(html.Label("Quantity:", className="fw-bold"), width=5),
                        dbc.Col(html.Span(id="qty_display", className="text-muted"), width=7)
                    ], className="mb-3 border-bottom"), # Added spacing
                    

                ], width=6),

                # Manual Entry
                dbc.Col([
                    html.H5("Manual Entry", className="fw-bold text-primary mb-3"),

                    dbc.Input(id="desc", placeholder="Description", className="mt-2"),
                    dbc.Input(id="vcode", placeholder="Vendor Code", className="mt-2"),
                    dbc.Input(id="invno", placeholder="Invoice No", className="mt-2"),

                    dcc.DatePickerSingle(
                        id="invdt",
                        placeholder="Invoice Date",
                        className="mt-3",
                        display_format="DD-MM-YYYY",
                        style={"width": "100%"},
                    ),

                    dbc.Button(
                        "Submit",
                        id="submit_btn",
                        color="success",
                        # --- MODIFICATION FOR SMALL & CENTERED BUTTON ---
                        className="d-block mx-auto mt-4 fw-bold", 
                        style={"width": "150px"} # Smaller size
                        # -----------------------------------------------
                    ),
                    html.Div(
                        id="status",
                        className="mt-3 text-center text-success fw-bold"
                    ),
                ], width=6),
            ]),
        ])

    ], className="shadow mb-5"),

     # =======================
     # Data Table Card
     # =======================
     dbc.Card([
         dbc.CardHeader(
             "QR Scan Log – Live Records",
             className="fw-bold",
             style={"backgroundColor": "#1f2937", "color": "white",'text-align':'center'}
         ),
         dbc.CardBody([
             dash_table.DataTable(
                 id="qr_table",
                 columns=[{"name": c, "id": c} for c in COLUMNS],
                 data=data_Live.to_dict("records"),

                 style_table={
                     "overflowY": "auto", 
                     "height": "400px",
                     "borderRadius": "10px",
                 },
                 style_cell={
                     "textAlign": "center",
                     "fontSize": "13px",
                     "padding": "6px",
                     "whiteSpace": "normal",
                     "backgroundColor": "white"
                 },
                 style_header={
                     "backgroundColor": "#4b5563",
                     "color": "white",
                     "fontWeight": "bold",
                     "fontSize": "13px",
                 },
                 style_data_conditional=[
                     {   # Row with GR number
                         "if": {"filter_query": "{GR_No} != ''"},
                         "backgroundColor": "#d1fae5"
                     },
                     {   # Pending GR
                         "if": {"filter_query": "{GR_No} = ''"},
                         "backgroundColor": "#fef3c7"
                     },
                 ],
             )
         ])
     ], className="mb-4 shadow"),
    # =======================
    # Camera Feed (Floating)
    # =======================
    html.Div([
        html.Img(
            id='camera_feed',
            src="/video_feed",
            style={
                "width": "170px",
                "height": "170px",
                "border": "3px solid #1f2937",
                "borderRadius": "12px",
                "boxShadow": "0px 2px 10px rgba(0,0,0,0.3)"
            }
        )
    ],
    id="camera_div",
    style={
        "position": "fixed",
        "top": "80%",
        "left": "50%",
        "transform": "translate(-50%, -50%)",
        "zIndex": "9999",
        "cursor": "move"
    }),

    # Refresh intervals
    dcc.Interval(id="watch_qr", interval=1000),
    dcc.Interval(id="refresh", interval=1500, n_intervals=0),

], fluid=True)


@app.callback(
    [
        Output("qr_table", "data"),
        Output("duplicate_alert", "children"),
        Output("duplicate_alert", "style")
    ],
    Input("watch_qr", "n_intervals")
)
def update_table(n):
    global duplicate_alert_msg, duplicate_alert_time

    df_latest = load_from_db_live().sort_values(by="Timestamp", ascending=False)

    # ---- Auto-hide alert logic (3 seconds) ----
    if duplicate_alert_time:
        elapsed = (datetime.now() - duplicate_alert_time).total_seconds()
        if elapsed > 3:
            duplicate_alert_msg = ""
            duplicate_alert_time = None

    # ---- Build alert style ----
    alert_style = {
        "color": "white",
        "backgroundColor": "red",
        "padding": "10px",
        "textAlign": "center",
        "fontWeight": "bold",
        "borderRadius": "5px",
        "marginBottom": "10px",
        "display": "block" if duplicate_alert_msg else "none"
    }

    return df_latest.to_dict("records"), duplicate_alert_msg, alert_style


@app.callback(
    [
        Output("bel_display", "children"),
        Output("mpn_display", "children"),
        Output("batch_display", "children"),
        Output("dc_display", "children"),
        Output("qty_display", "children"),
    ],
    Input("refresh", "n_intervals")
)
def show_scanned_data(n):
    if latest_qr_data:
        return (
            latest_qr_data["BEL_Part_Number"],
            latest_qr_data["MPN"],
            latest_qr_data["Batch_Lot_No"],
            latest_qr_data["DateCode"],
            latest_qr_data["Quantity"],
        )
    return ["", "", "", "", ""]







@app.callback(
    Output("status", "children"),
    Input("submit_btn", "n_clicks"),
    [

        # Note: We rely on the global 'latest_qr_data' for the scanned fields, 
        # and only use the State for the manually entered fields.
        State("desc", "value"),
        State("vcode", "value"),
        State("invno", "value"),
        State("invdt", "date")
    ]
)
def save_final(n, desc, vcode, invno, invdt):

    if not n:
        return ""
    
    if not latest_qr_data:
        return "⚠️ Please scan a QR code first."


    try:
        db = next(init_db())   
        count = db.query(LogBook_db).count()    
        db_record = DB_QRRecord(
            Timestamp=datetime.now(),
            BEL_Part_Number=latest_qr_data["BEL_Part_Number"],
            MPN=latest_qr_data["MPN"],
            Batch_Lot_No=latest_qr_data["Batch_Lot_No"],
            DateCode=latest_qr_data["DateCode"],
            Quantity=latest_qr_data["Quantity"],
            BEL_PO_No=latest_qr_data["BEL_PO_No"],
            Vendor_Name=latest_qr_data["Vendor_Name"],
            OEM_Make=latest_qr_data["OEM_Make"],
            Manufacturing_Place=latest_qr_data["Manufacturing_Place"],
            GR_No=latest_qr_data["GR_No"],
            GR_Date=datetime.strptime(latest_qr_data["GR_Date"], "%Y-%m-%d"),
            Reference_No=latest_qr_data["Reference_No"],
            Description=desc,
            Vendor_Code=vcode,
            Invoice_No=invno,
            Invoice_Dt=invdt,
            SL_No = str(count)
        )
        db.add(db_record)
        db.commit()
        # 'parsed' global variable should hold the last scanned data if the system is running correctly
        print(f"✅ Added to DB: GR={latest_qr_data['GR_No']} | Ref={latest_qr_data['Reference_No']}")
    except Exception as e:
        print("❌ Database insert failed:", e)
        return f"❌ Database insertion failed! Error: {e}"
    finally:
        db.close()

    return "✔ Record saved to QRRecord_db successfully!"


if __name__ == "__main__":
    app.run(debug=True, port=7000)


























# import cv2
# from pyzbar import pyzbar
# import pandas as pd
# from datetime import datetime
# import os, hashlib, re
# from flask import Flask, Response
# import dash
# from dash import dash_table, html, dcc, Input, Output
# import dash_bootstrap_components as dbc
# import numpy as np
# import time
# import base64 
# import io 

# from sqlalchemy.orm import Session
# from Data_Server import init_db
# from Database_models import QRRecord_db as DB_QRRecord, QRRecord_Generated,LogBook_db
# from dash import Dash, html, dcc
# from dash import Input, Output, State

# # Global variables (Defined once, used to store state across threads/sessions)
# latest_qr_data = None
# duplicate_alert_msg = ""
# duplicate_alert_time = None
# camera_instance = None 

# # ==============================
# # Image Encoding Utility
# # ==============================
# def encode_image(frame):
#     """Converts an OpenCV image frame to a base64 URL for Dash display."""
#     if frame is None:
#         return ""
    
#     # Encode frame to JPEG
#     # Use a high quality setting (95) for better visibility of QR/bounding boxes
#     ret, buffer = cv2.imencode('.jpeg', frame, [cv2.IMWRITE_JPEG_QUALITY, 95])
#     if not ret:
#         return ""
    
#     # Convert buffer to base64 string
#     jpg_as_text = base64.b64encode(buffer).decode('utf-8')
#     return f'data:image/jpeg;base64,{jpg_as_text}'


# # ==============================
# # Configuration
# # ==============================
# CSV_FILE = "qr_log_parsed.csv"
# COLUMNS = [
#     "Timestamp", "SL_No", "BEL_Part_Number", "MPN", "Batch_Lot_No",
#     "DateCode", "Quantity", "BEL_PO_No", "Vendor_Name", "OEM_Make",
#     "Manufacturing_Place", "GR_No", "GR_Date", "Reference_No","Description", "Vendor_Code",
#     "Invoice_No",
#     "Invoice_Dt"
# ]
# COLUMNS_Log_Book = [
#     "Timestamp", "SL_No", "BEL_Part_Number", "MPN", "Batch_Lot_No",
#     "DateCode", "Quantity", "BEL_PO_No", "Vendor_Name", "OEM_Make",
#     "Manufacturing_Place",]

# def load_from_db_live():
#     """Fetch all QR records from the database."""
#     try:
#         db = next(init_db())
#         records = db.query(DB_QRRecord).all()
#         if not records:
#             # Return empty dataframe with predefined columns
#             return pd.DataFrame(columns=COLUMNS)

#         df = pd.DataFrame([{
#             "Timestamp": r.Timestamp.strftime("%Y-%m-%d %H:%M:%S") if r.Timestamp else "",
#             "SL_No": r.SL_No,
#             "BEL_Part_Number": r.BEL_Part_Number,
#             "MPN": r.MPN,
#             "Batch_Lot_No": r.Batch_Lot_No,
#             "DateCode": r.DateCode,
#             "Quantity": r.Quantity,
#             "BEL_PO_No": r.BEL_PO_No,
#             "Vendor_Name": r.Vendor_Name,
#             "OEM_Make": r.OEM_Make,
#             "Manufacturing_Place": r.Manufacturing_Place,
#             "GR_No": r.GR_No,
#             "GR_Date": r.GR_Date.strftime("%Y-%m-%d") if r.GR_Date else "",
#             "Reference_No": r.Reference_No,
#             "Description": r.Description,
#             "Vendor_Code": r.Vendor_Code,
#             "Invoice_No": r.Invoice_No,
#             "Invoice_Dt": r.Invoice_Dt
#         } for r in records])

#         # Ensure all expected columns exist
#         for col in COLUMNS:
#             if col not in df.columns:
#                 df[col] = ""

#         return df[COLUMNS]

#     except Exception as e:
#         print("❌ Database read failed:", e)
#         return pd.DataFrame(columns=COLUMNS)
#     finally:
#         db.close()

# def load_from_db():
#     """Fetch all QR records from the database."""
#     try:
#         db = next(init_db())
#         records = db.query(QRRecord_Generated).all()
#         if not records:
#             # Return empty dataframe with predefined columns
#             return pd.DataFrame(columns=COLUMNS)

#         df = pd.DataFrame([{
#             "Timestamp": r.Timestamp.strftime("%Y-%m-%d %H:%M:%S") if r.Timestamp else "",
#             "SL_No": r.SL_No,
#             "BEL_Part_Number": r.BEL_Part_Number,
#             "MPN": r.MPN,
#             "Batch_Lot_No": r.Batch_Lot_No,
#             "DateCode": r.DateCode,
#             "Quantity": r.Quantity,
#             "BEL_PO_No": r.BEL_PO_No,
#             "Vendor_Name": r.Vendor_Name,
#             "OEM_Make": r.OEM_Make,
#             "Manufacturing_Place": r.Manufacturing_Place,
#             "GR_No": r.GR_No,
#             "GR_Date": r.GR_Date.strftime("%Y-%m-%d") if r.GR_Date else "",
#             "Reference_No": r.Reference_No,
#             "Description": r.Description,
#             "Vendor_Code": r.Vendor_Code,
#             "Invoice_No": r.Invoice_No,
#             "Invoice_Dt": r.Invoice_Dt
#         } for r in records])

#         # Ensure all expected columns exist
#         for col in COLUMNS:
#             if col not in df.columns:
#                 df[col] = ""

#         return df[COLUMNS]

#     except Exception as e:
#         print("❌ Database read failed:", e)
#         return pd.DataFrame(columns=COLUMNS)
#     finally:
#         db.close()

# df = load_from_db()

# def load_from_log_book():
#     """Fetch all QR records from the database."""
#     try:
#         db = next(init_db())
#         records = db.query(LogBook_db).all()
#         if not records:
#             # Return empty dataframe with predefined columns
#             return pd.DataFrame(columns=COLUMNS_Log_Book)

#         df = pd.DataFrame([{
#             "Timestamp": r.Timestamp.strftime("%Y-%m-%d %H:%M:%S") if r.Timestamp else "",
#             "SL_No": r.SL_No,
#             "BEL_Part_Number": r.BEL_Part_Number,
#             "MPN": r.MPN,
#             "Batch_Lot_No": r.Batch_Lot_No,
#             "DateCode": r.DateCode,
#             "Quantity": r.Quantity,
#             "BEL_PO_No": r.BEL_PO_No,
#             "Vendor_Name": r.Vendor_Name,
#             "OEM_Make": r.OEM_Make,
#             "Manufacturing_Place": r.Manufacturing_Place,
            
#         } for r in records])

#         # Ensure all expected columns exist
#         for col in COLUMNS_Log_Book:
#             if col not in df.columns:
#                 df[col] = ""

#         return df[COLUMNS_Log_Book]

#     except Exception as e:
#         print("❌ Database read failed:", e)
#         return pd.DataFrame(columns=COLUMNS_Log_Book)
#     finally:
#         db.close()

# df_Log_Book = load_from_log_book()
# # ==============================
# # Utility & Hashing
# # ==============================
# def clean_text(value: str) -> str:
#     """Remove spaces and symbols, keep only letters/numbers."""
#     if not isinstance(value, str):
#         value = str(value)
#     return re.sub(r"[^A-Za-z0-9]", "", value).upper()

# def hash_32bit(input_str: str) -> str:
#     """Return uppercase 8-char (32-bit) hex hash."""
#     return hashlib.md5(input_str.encode()).hexdigest()[:8].upper()

# def row_hash(row):
#     """
#     Generate a 32-bit hash for duplicate detection.
#     - Considers only alphanumeric characters (A–Z, 0–9)
#     - Ignores case, spaces, punctuation, and non-key columns
#     """
#     relevant_cols = [
#         c for c in COLUMNS 
#         if c not in ["Timestamp", "GR_No", "GR_Date", "Reference_No", "SL_No"]
#     ]

#     concat_str = ""
#     for c in relevant_cols:
#         val = str(row.get(c, ""))
#         val = re.sub(r"[^A-Za-z0-9]", "", val).upper()  # keep only alphanumeric
#         concat_str += val + "_"

#     return hashlib.md5(concat_str.encode()).hexdigest()

# # ==============================
# # GR Number (32-bit hash)
# # ==============================
# def generate_gr_no(parsed):
#     """Generate a deterministic GR_No based on key fields."""
#     base_key = (
#         clean_text(parsed.get("BEL_PO_No", "")) +
#         clean_text(parsed.get("BEL_Part_Number", "")) +
#         clean_text(parsed.get("Batch_Lot_No", "")) +
#         clean_text(parsed.get("DateCode", "")) +
#         clean_text(parsed.get("Vendor_Name", ""))
#     )
#     return hash_32bit(base_key)

# # ==============================
# # Optimized Reference Number Generator
# # ==============================
# existing_refs = {}  # Memory cache for Reference_No versioning

# def generate_reference_no(parsed):
#     """
#     Generate a stable 32-bit Reference_No with version suffixes.
#     - If new PO+Part → new hash.
#     - If same combo and fields unchanged → reuse.
#     - If changed → append _1, _2, etc.
#     """
#     po = parsed.get("Vendor_Name", "")
#     part = parsed.get("BEL_Part_Number", "")
#     key_pair = (po, part)
#     compare_fields = ["Quantity", "Batch_Lot_No", "DateCode", "BEL_PO_No"]

#     # If first time for this PO+Part combo
#     if key_pair not in existing_refs:
#         key = (
#             clean_text(po)
#             + clean_text(part)
#             + clean_text(parsed.get("BEL_PO_No", ""))
#             + clean_text(parsed.get("Quantity", ""))
#             + clean_text(parsed.get("Batch_Lot_No", ""))
#             + clean_text(parsed.get("DateCode", ""))
#         )
#         base_ref = hash_32bit(key)
#         existing_refs[key_pair] = {
#             "last_fields": {f: parsed.get(f, "") for f in compare_fields},
#             "base_ref": base_ref,
#             "suffix_count": 0,
#         }
#         return base_ref
#     print("key_pair")
#     # Compare current to last recorded fields
#     record = existing_refs[key_pair]
#     changed = any(
#         clean_text(record["last_fields"].get(f, "")) != clean_text(parsed.get(f, ""))
#         for f in compare_fields
#     )
#     print("changed",changed)
#     if not changed:
#         return (
#             f"{record['base_ref']}_{record['suffix_count']}"
#             if record["suffix_count"] > 0
#             else record["base_ref"]
#         )

#     # If changed → increment suffix

#     record["suffix_count"] += 1
#     print(record["suffix_count"])
#     record["last_fields"] = {f: parsed.get(f, "") for f in compare_fields}
#     print(f"{record['base_ref']}_{record['suffix_count']}")
#     return f"{record['base_ref']}_{record['suffix_count']}"

# # ==============================
# # QR Parsing
# # ==============================
# def parse_qr_data(qr_text):
#     data = {col: "" for col in COLUMNS}
#     data["Timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

#     for line in qr_text.splitlines():
#         if ":" in line:
#             key, value = line.split(":", 1)
#             key = key.strip().lower().replace(" ", "")
#             value = value.strip()
#             if "belpartnumber" in key: data["BEL_Part_Number"] = value
#             elif "mpn" in key: data["MPN"] = value
#             elif "batch/lotno" in key: data["Batch_Lot_No"] = value
#             elif "datecode" in key: data["DateCode"] = value
#             elif "quantity" in key: data["Quantity"] = value
#             elif "belpono" in key: data["BEL_PO_No"] = value
#             elif "vendorname" in key: data["Vendor_Name"] = value
#             elif "oem/make" in key: data["OEM_Make"] = value
#             elif "manufacturingplace" in key: data["Manufacturing_Place"] = value
#     return data



# def save_logbook(parsed):
#     try:
#         db = next(init_db())
                
#         db_record = LogBook_db(
#             Timestamp=datetime.now(),
#             BEL_Part_Number=parsed["BEL_Part_Number"],
#             MPN=parsed["MPN"],
#             Batch_Lot_No=parsed["Batch_Lot_No"],
#             DateCode=parsed["DateCode"],
#             Quantity=parsed["Quantity"],
#             BEL_PO_No=parsed["BEL_PO_No"],
#             Vendor_Name=parsed["Vendor_Name"],
#             OEM_Make=parsed["OEM_Make"],
#             Manufacturing_Place=parsed["Manufacturing_Place"],
#         )
#         db.add(db_record)
#         db.commit()
#     except Exception as e:
#                 print("❌ Database insert failed:", e)
#     finally:
#         db.close()
# # ==============================
# # Flask + Dash
# # =======================================================
# server = Flask(__name__)

# # NOTE: The /video_feed route and generate_frames function are removed for stability.

# app = dash.Dash(__name__, server=server, external_stylesheets=[dbc.themes.LITERA])
# app.title = "SAP Data Entry - QR Scanner"
# data_Live = load_from_db_live()


# app.layout = dbc.Container([

#     # =======================
#     # Header
#     # =======================
#     dbc.Row([
#         dbc.Col([
#             html.H2(
#                 "SAP Data Entry Automation – GR/Reference Generator",
#                 className="text-center my-4 fw-bold",
#                 style={"color": "#1f2937"}
#             )
#         ], width=10),
        
#         # --- Scan QR Button (Top Right) ---
#         dbc.Col([
#             dbc.Button(
#                 "Scan QR",
#                 id="scan_qr_btn",
#                 color="info",
#                 className="mt-4 mb-2 float-end fw-bold",
#                 style={"width": "100px"}
#             )
#         ], width=2)
#     ]),

#     # =======================
#     # Duplicate Alert Banner
#     # =======================
#     html.Div(
#         id="duplicate_alert",
#         style={
#             "color": "white",
#             "backgroundColor": "#d9534f",
#             "padding": "12px",
#             "textAlign": "center",
#             "fontWeight": "bold",
#             "display": "none",
#             "borderRadius": "6px",
#             "marginBottom": "15px",
#             "boxShadow": "0px 2px 6px rgba(0,0,0,0.2)"
#         },
#     ),

#     # =======================
#     # Data Table Card
#     # =======================
#     dbc.Card([
#         dbc.CardHeader(
#             "QR Scan Log – Live Records",
#             className="fw-bold",
#             style={"backgroundColor": "#1f2937", "color": "white"}
#         ),
#         dbc.CardBody([
#             dash_table.DataTable(
#                 id="qr_table",
#                 columns=[{"name": c, "id": c} for c in COLUMNS],
#                 data=data_Live.to_dict("records"),

#                 style_table={
#                     "overflowY": "auto", 
#                     "height": "400px",
#                     "borderRadius": "10px",
#                 },
#                 style_cell={
#                     "textAlign": "center",
#                     "fontSize": "13px",
#                     "padding": "6px",
#                     "whiteSpace": "normal",
#                     "backgroundColor": "white"
#                 },
#                 style_header={
#                     "backgroundColor": "#4b5563",
#                     "color": "white",
#                     "fontWeight": "bold",
#                     "fontSize": "13px",
#                 },
#                 style_data_conditional=[
#                     {   # Row with GR number
#                         "if": {"filter_query": "{GR_No} != ''"},
#                         "backgroundColor": "#d1fae5"
#                     },
#                     {   # Pending GR
#                         "if": {"filter_query": "{GR_No} = ''"},
#                         "backgroundColor": "#fef3c7"
#                     },
#                 ],
#             )
#         ])
#     ], className="mb-4 shadow"),

#     # =======================
#     # Input Forms Section
#     # =======================
#     dbc.Card([
#         dbc.CardHeader(
#             "QR Data (Auto-Filled) & Manual Entry",
#             className="fw-bold",
#             style={"backgroundColor": "#1f2937", "color": "white"}
#         ),

#         dbc.CardBody([
#             dbc.Row([

#                 # Auto QR Fields (Label + Span for Data)
#                 dbc.Col([
#                     html.H5("Scanned QR Data", className="fw-bold text-primary mb-3"),

#                     dbc.Row([
#                         dbc.Col(html.Label("BEL Part Number:", className="fw-bold"), width=5),
#                         dbc.Col(html.Span(id="bel_display", className="text-muted"), width=7)
#                     ], className="mb-3 border-bottom"), 

#                     dbc.Row([
#                         dbc.Col(html.Label("MPN:", className="fw-bold"), width=5),
#                         dbc.Col(html.Span(id="mpn_display", className="text-muted"), width=7)
#                     ], className="mb-3 border-bottom"),

#                     dbc.Row([
#                         dbc.Col(html.Label("Batch/Lot No:", className="fw-bold"), width=5),
#                         dbc.Col(html.Span(id="batch_display", className="text-muted"), width=7)
#                     ], className="mb-3 border-bottom"),

#                     dbc.Row([
#                         dbc.Col(html.Label("Date Code:", className="fw-bold"), width=5),
#                         dbc.Col(html.Span(id="dc_display", className="text-muted"), width=7)
#                     ], className="mb-3 border-bottom"),
                    
#                     dbc.Row([
#                         dbc.Col(html.Label("Quantity:", className="fw-bold"), width=5),
#                         dbc.Col(html.Span(id="qty_display", className="text-muted"), width=7)
#                     ], className="mb-3 border-bottom"), 
                    

#                 ], width=6),

#                 # Manual Entry
#                 dbc.Col([
#                     html.H5("Manual Entry", className="fw-bold text-primary mb-3"),

#                     dbc.Input(id="desc", placeholder="Description", className="mt-2"),
#                     dbc.Input(id="vcode", placeholder="Vendor Code", className="mt-2"),
#                     dbc.Input(id="invno", placeholder="Invoice No", className="mt-2"),

#                     dcc.DatePickerSingle(
#                         id="invdt",
#                         placeholder="Invoice Date",
#                         className="mt-3",
#                         display_format="DD-MM-YYYY",
#                         style={"width": "100%"},
#                     ),

#                     dbc.Button(
#                         "Submit",
#                         id="submit_btn",
#                         color="success",
#                         className="d-block mx-auto mt-4 fw-bold", 
#                         style={"width": "150px"} 
#                     ),
#                     html.Div(
#                         id="status",
#                         className="mt-3 text-center text-success fw-bold"
#                     ),
#                 ], width=6),
#             ]),
#         ])

#     ], className="shadow mb-5"),


#     # =======================
#     # Camera Status and Image Display
#     # =======================
#     html.Div([
#         html.Div(
#             id='camera_status_indicator',
#             children="Press 'Scan QR' to activate camera.",
#             className="text-center text-info p-3 border rounded mb-2",
#         ),
#         # Element to show the captured image temporarily
#         html.Img(
#             id='captured_image_display',
#             src='',
#             style={
#                 "width": "100%",
#                 "height": "auto",
#                 "border": "3px solid #1f2937",
#                 "borderRadius": "12px",
#                 "boxShadow": "0px 2px 10px rgba(0,0,0,0.3)",
#                 "display": "none" # Hidden by default
#             }
#         )
#     ],
#     id="camera_feedback_container", 
#     style={
#         "position": "fixed",
#         "top": "75%",
#         "left": "50%",
#         "transform": "translate(-50%, -50%)",
#         "zIndex": "9999",
#         "width": "300px" # Increased size for better visual feedback
#     }),

#     # Interval to automatically hide the image after showing it
#     dcc.Interval(id="image_timer", interval=1000, n_intervals=0, disabled=True),
#     dcc.Interval(id="refresh", interval=1500, n_intervals=0),

# ], fluid=True)

# # --- IMAGE HIDING CALLBACK ---
# @app.callback(
#     Output("captured_image_display", "style"),
#     Output("image_timer", "disabled"),
#     Input("image_timer", "n_intervals"),
#     State("captured_image_display", "style"),
#     prevent_initial_call=True
# )
# def auto_hide_image(n_intervals, current_style):
#     # Hide the image after 2 seconds (n_intervals * interval)
#     if n_intervals >= 2:
#         current_style['display'] = 'none'
#         return current_style, True # Disable the timer
    
#     return current_style, False # Keep the timer running


# # --- SNAPSHOT CALLBACK (Handles everything: Open, Scan, Close) ---
# @app.callback(
#     [
#         Output("camera_status_indicator", "children"),
#         Output("qr_table", "data"),
#         Output("bel_display", "children"),
#         Output("mpn_display", "children"),
#         Output("batch_display", "children"),
#         Output("dc_display", "children"),
#         Output("qty_display", "children"),
#         Output("duplicate_alert", "children", allow_duplicate=True),
#         Output("duplicate_alert", "style", allow_duplicate=True),
#         Output("captured_image_display", "src"),
#         Output("captured_image_display", "style", allow_duplicate=True),
#         Output("image_timer", "n_intervals"), # Reset the timer counter
#         Output("image_timer", "disabled", allow_duplicate=True),
#     ],
#     Input("scan_qr_btn", "n_clicks"),
#     State("captured_image_display", "style"),
#     prevent_initial_call=True
# )
# def handle_scan_snapshot(n_clicks, current_img_style):

#     global latest_qr_data, duplicate_alert_msg, duplicate_alert_time

#     status_msg = "Opening camera..."
#     img_src = ''
    
#     # Initialize error outputs
#     output_data = dash.no_update
#     output_fields = [""] * 5
#     output_alert_msg = ""
#     output_alert_style = {"display": "none"}
    
#     # Image style to show the image
#     show_img_style = current_img_style.copy()
#     show_img_style['display'] = 'block'
    
#     cap = None
#     try:
#         # 1. Initialize and open the camera
#         cap = cv2.VideoCapture(0)
#         if not cap.isOpened():
#             status_msg = "❌ Camera Failed: Could not open video device (Check connection)."
#             print(status_msg)
#             return status_msg, output_data, *output_fields, output_alert_msg, output_alert_style, img_src, current_img_style, 0, True

#         status_msg = "Camera Active: Capturing image..."
        
#         # 2. Set higher resolution and wait for stabilization (IMPROVED STABILITY)
#         cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
#         cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
#         time.sleep(1.5) # Increased time for better focus

#         # 3. Discard initial frames 
#         for _ in range(5): 
#             cap.read() 

#         # 4. Capture final frame
#         success, frame = cap.read()
        
#         if not success:
#             status_msg = "❌ Capture Failed: Could not read frame."
#             print(status_msg)
#             return status_msg, output_data, *output_fields, output_alert_msg, output_alert_style, img_src, current_img_style, 0, True
        
#         # --- Pre-processing for better detection ---
#         display_frame = frame.copy()
#         gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
#         # 5. Process frame for QR code
#         qr_codes = pyzbar.decode(gray_frame)
        
#         disp_data = None

#         if not qr_codes:
#             status_msg = "⚠️ No QR code found in the captured image."
#             # Draw a failed detection outline
#             cv2.putText(display_frame, "QR NOT FOUND", (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            
#             # Use previously scanned data if available
#             disp_data = latest_qr_data if latest_qr_data else {k: "" for k in ["BEL_Part_Number", "MPN", "Batch_Lot_No", "DateCode", "Quantity"]}
            
#             img_src = encode_image(display_frame)
#             return status_msg, output_data, *[disp_data[k] for k in ["BEL_Part_Number", "MPN", "Batch_Lot_No", "DateCode", "Quantity"]], output_alert_msg, output_alert_style, img_src, show_img_style, 0, False # Enable timer

#         # --- 6. SUCCESS / DUPLICATE HANDLING ---
#         qr_text = qr_codes[0].data.decode("utf-8").strip()
#         parsed = parse_qr_data(qr_text)
        
#         # Draw bounding box on the image
#         x, y, w, h = qr_codes[0].rect
        
#         df_existing = load_from_log_book()
#         existing_hashes = set(row_hash(r) for _, r in df_existing.iterrows())
#         current_hash = row_hash(parsed)
        
#         if current_hash in existing_hashes:
#             output_alert_msg = "⚠️ Duplicate QR Detected!"
#             output_alert_style['display'] = 'block'
#             status_msg = "⚠️ Duplicate Scan Ignored."
            
#             cv2.rectangle(display_frame, (x, y), (x + w, y + h), (0, 0, 255), 2) # Red for Duplicate
            
#             disp_data = latest_qr_data if latest_qr_data else {k: "DUPLICATE" for k in ["BEL_Part_Number", "MPN", "Batch_Lot_No", "DateCode", "Quantity"]}

#         else:
#             # New scan successful
#             output_alert_msg = ""
            
#             cv2.rectangle(display_frame, (x, y), (x + w, y + h), (0, 255, 0), 2) # Green for Success
            
#             parsed["SL_No"] = str(len(df_existing) + 1)
#             parsed["GR_No"] = generate_gr_no(parsed)
#             parsed["GR_Date"] = datetime.now().strftime("%Y-%m-%d")
#             parsed["Reference_No"] = generate_reference_no(parsed)
#             latest_qr_data = parsed # Update global state
            
#             pd.DataFrame([parsed]).to_csv(CSV_FILE, mode="a", index=False, header=False)
#             save_logbook(latest_qr_data)
            
#             status_msg = "✅ Scan Successful! Data Loaded. Ready for Manual Entry."
#             disp_data = latest_qr_data

#         # --- 7. BUILD FINAL OUTPUTS ---
        
#         df_latest = load_from_db_live().sort_values(by="Timestamp", ascending=False)
#         img_src = encode_image(display_frame) # Encode the image with bounding box

#         return (
#             status_msg,
#             df_latest.to_dict("records"),
#             disp_data["BEL_Part_Number"],
#             disp_data["MPN"],
#             disp_data["Batch_Lot_No"],
#             disp_data["DateCode"],
#             disp_data["Quantity"],
#             output_alert_msg,
#             output_alert_style,
#             img_src,
#             show_img_style,
#             0, # Reset n_intervals
#             False # Enable timer
#         )

#     except Exception as e:
#         error_msg = f"❌ An internal processing error occurred: {e}"
#         print(f"Error in handle_scan_snapshot: {e}")
#         # Return error status and ensure image is hidden
#         return error_msg, output_data, *[""]*5, dash.no_update, dash.no_update, '', current_img_style, 0, True

#     finally:
#         # 8. Immediately release the camera resource (MOST IMPORTANT STEP)
#         if cap and cap.isOpened():
#              cap.release()
#              print("✅ Camera resource released (Snapshot finished).")


# # NOTE: The auto_update_status callback handles auto-hiding the duplicate alert.

# @app.callback(
#     [
#         Output("bel_display", "children", allow_duplicate=True),
#         Output("mpn_display", "children", allow_duplicate=True),
#         Output("batch_display", "children", allow_duplicate=True),
#         Output("dc_display", "children", allow_duplicate=True),
#         Output("qty_display", "children", allow_duplicate=True),
#         Output("duplicate_alert", "children", allow_duplicate=True),
#         Output("duplicate_alert", "style", allow_duplicate=True),
#     ],
#     Input("refresh", "n_intervals"),
#     prevent_initial_call=True
# )
# def auto_update_status(n):
#     global duplicate_alert_msg, duplicate_alert_time, latest_qr_data

#     # --- Auto-hide alert logic (3 seconds) ----
#     if duplicate_alert_time:
#         elapsed = (datetime.now() - duplicate_alert_time).total_seconds()
#         if elapsed > 3:
#             duplicate_alert_msg = ""
#             duplicate_alert_time = None
    
#     alert_style = {
#         "color": "white",
#         "backgroundColor": "red",
#         "padding": "10px",
#         "textAlign": "center",
#         "fontWeight": "bold",
#         "borderRadius": "5px",
#         "marginBottom": "10px",
#         "display": "block" if duplicate_alert_msg else "none"
#     }

#     if latest_qr_data:
#         return (
#             latest_qr_data["BEL_Part_Number"],
#             latest_qr_data["MPN"],
#             latest_qr_data["Batch_Lot_No"],
#             latest_qr_data["DateCode"],
#             latest_qr_data["Quantity"],
#             duplicate_alert_msg,
#             alert_style,
#         )
    
#     return [dash.no_update] * 5 + [duplicate_alert_msg, alert_style]


# @app.callback(
#     Output("status", "children"),
#     Input("submit_btn", "n_clicks"),
#     [
#         State("desc", "value"),
#         State("vcode", "value"),
#         State("invno", "value"),
#         State("invdt", "date")
#     ]
# )
# def save_final(n, desc, vcode, invno, invdt):
#     global latest_qr_data

#     if not n:
#         return ""
    
#     if not latest_qr_data:
#         return "⚠️ Please scan a QR code first."
    
#     # Check if the currently displayed data is a duplicate placeholder
#     if latest_qr_data.get("BEL_Part_Number") == "DUPLICATE":
#         return "❌ Cannot submit: Please scan a unique QR code."


#     try:
#         db = next(init_db())   
#         count = db.query(LogBook_db).count()    
#         db_record = DB_QRRecord(
#             Timestamp=datetime.now(),
#             BEL_Part_Number=latest_qr_data["BEL_Part_Number"],
#             MPN=latest_qr_data["MPN"],
#             Batch_Lot_No=latest_qr_data["Batch_Lot_No"],
#             DateCode=latest_qr_data["DateCode"],
#             Quantity=latest_qr_data["Quantity"],
#             BEL_PO_No=latest_qr_data["BEL_PO_No"],
#             Vendor_Name=latest_qr_data["Vendor_Name"],
#             OEM_Make=latest_qr_data["OEM_Make"],
#             Manufacturing_Place=latest_qr_data["Manufacturing_Place"],
#             GR_No=latest_qr_data["GR_No"],
#             GR_Date=datetime.strptime(latest_qr_data["GR_Date"], "%Y-%m-%d"),
#             Reference_No=latest_qr_data["Reference_No"],
#             Description=desc,
#             Vendor_Code=vcode,
#             Invoice_No=invno,
#             Invoice_Dt=invdt,
#             SL_No = str(count)
#         )
#         db.add(db_record)
#         db.commit()
#         print(f"✅ Added to DB: GR={latest_qr_data['GR_No']} | Ref={latest_qr_data['Reference_No']}")
#     except Exception as e:
#         print("❌ Database insert failed:", e)
#         return f"❌ Database insertion failed! Error: {e}"
#     finally:
#         db.close()

#     return "✔ Record saved to QRRecord_db successfully!"


# if __name__ == "__main__":
#     app.run(debug=True, port=7000)