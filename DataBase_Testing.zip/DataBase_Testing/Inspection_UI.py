# import dash
# from dash import html, dcc, Input, Output, State, dash_table
# import dash_bootstrap_components as dbc
# import pandas as pd
# from datetime import datetime, date # Ensure 'date' class is imported from datetime module
# import traceback
# from sqlalchemy.orm import joinedload # NEW IMPORT: Needed to prevent lazy-loading errors

# # NOTE: These imports rely on Database.py and Database_models.py being accessible.
# from Database import session
# from Database_models import (
#     QRRecord_Generated,
#     SubContract_Inspection,
#     DimensionReport,
#     DimensionSample,
#     DimensionCommonReport,
#     DimensionType,
# )

# # ---------------------------
# # DB FETCH FUNCTIONS
# # ---------------------------

# def get_refs_from_db():
#     """Fetches all Reference Numbers available in the generated records."""
#     db = session()
#     try:
#         refs = db.query(QRRecord_Generated.Reference_No).all()
#         return sorted([r[0] for r in refs])
#     except Exception as e:
#         print(f"Error fetching references: {e}")
#         return []
#     finally:
#         db.close()

# def get_qr_record(ref_no):
#     """Fetches the main QR record (source data)."""
#     db = session()
#     try:
#         return db.query(QRRecord_Generated).filter_by(Reference_No=ref_no).first()
#     finally:
#         db.close()

# def get_subcontract(ref_no):
#     """Fetches the Subcontract Inspection report."""
#     db = session()
#     try:
#         return db.query(SubContract_Inspection).filter_by(Reference_No=ref_no).first()
#     finally:
#         db.close()

# def get_dimension_common(ref_no):
#     """Fetches the Common Dimension Report (Header data)."""
#     db = session()
#     try:
#         # Assuming DimensionCommonReport exists and is linked
#         return db.query(DimensionCommonReport).filter_by(Reference_No=ref_no).first()
#     except Exception:
#         # Handle case where the table/model might be missing or misconfigured
#         return None
#     finally:
#         db.close()

# def get_dimensions(ref_no):
#     """
#     Fetches all detailed Dimension Reports for a given Reference_No,
#     FORCING the related DimensionType to load immediately (joinedload).
#     """
#     db = session()
#     try:
#         return (
#             db.query(DimensionReport)
#             .options(joinedload(DimensionReport.dimension_type)) # FIX: Eager load the relationship
#             .filter(DimensionReport.Reference_No == ref_no)
#             .all()
#         )
#     finally:
#         db.close()

# def get_samples(report_id):
#     """Fetches all Dimension Samples associated with a specific DimensionReport ID."""
#     db = session()
#     try:
#         return (
#             db.query(DimensionSample)
#             .filter_by(Report_Id=report_id)
#             .order_by(DimensionSample.Sample_No)
#             .all()
#         )
#     finally:
#         db.close()

# # ---------------------------
# # DASH APP LAYOUT & STYLES
# # ---------------------------

# # Fix for ValueError: The name '_dash_assets' is already registered:
# # Ensure we only instantiate the Dash app once, without creating a separate server variable
# # that might cause conflicts in some environments.
# app = dash.Dash(__name__, external_stylesheets=[dbc.themes.PULSE]) 
# app.title = "Inspection Dashboard"

# # Helper function to format attribute names nicely
# def format_key(key):
#     return key.replace('_', ' ').title().replace('No', 'No.').replace('Dt', 'Date')

# # Card generator for key-value pairs
# def create_summary_block(title, data_object, fields):
#     if not data_object:
#         return html.P(f"No {title.lower()} data found.", className="text-muted fst-italic p-2")

#     items = []
#     for field in fields:
#         value = getattr(data_object, field, None)
#         if value is not None:
#             # FIX: Ensure we check against the imported 'datetime' class and 'date' class
#             if isinstance(value, (datetime, date)): 
#                 value = value.strftime("%Y-%m-%d")
            
#             # Use appropriate colors for status/inspection fields
#             color_class = "text-dark"
#             if "Inspection" in field or "Report" in field or "Material" in field:
#                  if str(value).upper() in ["OK", "ACCEPTED"]:
#                     color_class = "text-success fw-bold"
#                  elif str(value).upper() in ["NOT OK", "REJECTED"]:
#                     color_class = "text-danger fw-bold"
#                  elif str(value).upper() in ["PENDING", "N/A"]:
#                     color_class = "text-warning"
            
#             items.append(
#                 dbc.Row([
#                     dbc.Col(html.B(f"{format_key(field)}:"), width=5, className="text-secondary"),
#                     dbc.Col(html.Div(str(value), className=color_class)),
#                 ], className="g-0 border-bottom py-1")
#             )
#     return html.Div(items, className="p-2")


# app.layout = dbc.Container(
#     [
#         html.H2("Component Inspection Data Viewer", className="text-center my-4 text-primary"),

#         # 1. Dropdown Row
#         dbc.Row(
#             dbc.Col(
#                 dbc.Card(
#                     [
#                         dbc.CardHeader("Select Reference Number", className="bg-info text-white fw-bold"),
#                         dbc.CardBody(
#                             [
#                                 dcc.Dropdown(
#                                     id="ref-dropdown",
#                                     options=[{"label": r, "value": r} for r in get_refs_from_db()],
#                                     clearable=True,
#                                     placeholder="Choose Reference_No to load full inspection details",
#                                     className="mb-2"
#                                 ),
#                                 html.Small(id="ref-last-loaded", className="text-muted d-block text-center pt-2")
#                             ]
#                         ),
#                     ], className="shadow-lg mb-4"
#                 ),
#                 width={"size": 6, "offset": 3},
#             )
#         ),

#         html.Hr(),

#         dbc.Row(
#             [
#                 # Left column (Summary Blocks)
#                 dbc.Col(
#                     [
#                         # QR Record Summary
#                         dbc.Card(
#                             [
#                                 dbc.CardHeader("Source QR Record & Logistics", className="bg-light fw-bold"),
#                                 dbc.CardBody(html.Div(id="qr-summary")),
#                             ],
#                             className="mb-4 shadow-sm",
#                         ),

#                         # Subcontract Summary
#                         dbc.Card(
#                             [
#                                 dbc.CardHeader("Subcontract Inspection Status", className="bg-light fw-bold"),
#                                 dbc.CardBody(html.Div(id="subcontract-summary")),
#                             ],
#                             className="mb-4 shadow-sm",
#                         ),
                        
#                         # Common Dimension Info
#                         dbc.Card(
#                             [
#                                 dbc.CardHeader("Common Dimensional/Electrical Checks", className="bg-light fw-bold"),
#                                 dbc.CardBody(html.Div(id="common-dim")),
#                             ],
#                             className="mb-4 shadow-sm",
#                         ),
#                     ],
#                     width=4,
#                 ),

#                 # Right column (Dimension Details)
#                 dbc.Col(
#                     [
#                         dbc.Card(
#                             [
#                                 dbc.CardHeader("Detailed Dimension Reports", className="bg-primary text-white fw-bold"),
#                                 dbc.CardBody(
#                                     [
#                                         # Dimension Report Table (Overview)
#                                         html.Div(id="dimension-table"),
                                        
#                                         html.Br(),
#                                         html.Label("Select Dimension for Sample Data:", className="fw-bold text-primary"),
                                        
#                                         # Dimension Dropdown
#                                         dcc.Dropdown(
#                                             id="dimension-select", 
#                                             options=[], 
#                                             clearable=True,
#                                             placeholder="Select a dimension row ID for detailed samples"
#                                         ),
                                        
#                                         html.Br(),
                                        
#                                         # Samples Table
#                                         dbc.Card(
#                                             [
#                                                 dbc.CardHeader("Measurement Samples"),
#                                                 dbc.CardBody(html.Div(id="samples-table"))
#                                             ], className="shadow-sm mt-3"
#                                         )
#                                     ]
#                                 ),
#                             ], className="shadow-lg"
#                         )
#                     ],
#                     width=8,
#                 ),
#             ]
#         ),
#     ],
#     fluid=True,
# )

# # ---------------------------
# # CALLBACK – WHEN REF SELECTED
# # ---------------------------

# @app.callback(
#     [
#         Output("qr-summary", "children"),
#         Output("subcontract-summary", "children"),
#         Output("common-dim", "children"),
#         Output("dimension-table", "children"),
#         Output("dimension-select", "options"),
#         Output("ref-last-loaded", "children"),
#     ],
#     Input("ref-dropdown", "value"),
# )
# def load_reference_data(ref):
#     if not ref:
#         empty_message = html.P("Select a Reference Number above to view details.")
#         return [empty_message] * 5 + [""]

#     try:
#         # --- Fetch all data ---
#         qr = get_qr_record(ref)
#         subcontract = get_subcontract(ref)
#         common = get_dimension_common(ref)
#         dims = get_dimensions(ref)

#         # --- 1. QR Summary ---
#         qr_fields = ["BEL_Part_Number", "MPN", "Vendor_Name", "Quantity", "GR_No", "Invoice_No", "GR_Date", "Description"]
#         qr_block = create_summary_block("QR Record", qr, qr_fields)

#         # --- 2. Subcontract Summary ---
#         sc_fields = ["SAN_NO", "Control_No", "PO_NO", "Sample", "Drg_Issue_Level", 
#                      "Visual_Inspection", "Vendor_Dimension_Report", "Raw_Material_Supplied", "Raw_Material_Test_Report"]
#         sc_block = create_summary_block("Subcontract", subcontract, sc_fields)

#         # --- 3. Common Dimension Info (Custom fields for clarity) ---
#         common_fields = ["Dimension_Remark", "Electrical_Inspection_Remark", "Visual_Inspection_Report",
#                          "Qty_Received", "Qty_Inspected", "Qty_Accepted", "Inspection_Remarks"]
#         common_items = create_summary_block("Common Dimension", common, common_fields)

#         # --- 4. Dimension Reports Table ---
#         dim_options = []
#         if dims:
#             df = pd.DataFrame(
#                 [
#                     {
#                         "Report_Id": d.Id,
#                         "Dimension": d.dimension_type.Name if d.dimension_type else "N/A", 
#                         "Basic Dim.": d.Basic_Dimension,
#                         "Tolerance": d.Tolerance,
#                         "Min Value": d.Min,
#                         "Max Value": d.Max,
#                     }
#                     for d in dims
#                 ]
#             )
#             dim_table = dash_table.DataTable(
#                 columns=[{"name": format_key(i), "id": i} for i in df.columns],
#                 data=df.to_dict("records"),
#                 style_table={'overflowX': 'auto', 'borderRadius': '5px'},
#                 style_cell={"textAlign": "center", "padding": "8px", 'fontSize': '12px'},
#                 style_header={"backgroundColor": "#4682B4", "color": "white", "fontWeight": "bold", 'fontSize': '13px'},
#                 id="dimension-report-table-output"
#             )

#             dim_options = [{"label": f"{d.dimension_type.Name} (ID: {d.Id})", "value": d.Id} for d in dims if d.dimension_type]
#         else:
#             dim_table = html.P("No detailed dimensions defined for this reference.", className="text-warning p-2")

#         return (
#             qr_block,
#             sc_block,
#             common_items,
#             dim_table,
#             dim_options,
#             f"Last loaded: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
#         )
#     except Exception as e:
#         error_info = html.Div([
#             html.P("An unexpected error occurred while fetching data:", className="text-danger"),
#             html.Pre(traceback.format_exc())
#         ])
#         print(f"Error in load_reference_data: {traceback.format_exc()}")
#         return [error_info] * 5 + [f"Error at {datetime.now().strftime('%H:%M:%S')}"]


# # ---------------------------
# # CALLBACK – SHOW SAMPLES
# # ---------------------------

# @app.callback(
#     Output("samples-table", "children"),
#     Input("dimension-select", "value"),
# )
# def load_samples(report_id):
#     if not report_id:
#         return html.P("Select a Dimension Report ID above to view individual samples.", className="text-muted p-2")

#     try:
#         samples = get_samples(report_id)
#         if not samples:
#             return html.P("No samples found for this dimension.", className="text-warning p-2")

#         df = pd.DataFrame(
#             [
#                 {
#                     "Sample No.": s.Sample_No, 
#                     "Value": s.Value, 
#                     "Status": s.Status,
#                     "Unit": s.Dimension_Parameter_Unit,
#                     "Remarks": s.Remarks or "N/A"
#                 } for s in samples
#             ]
#         )

#         return dash_table.DataTable(
#             columns=[{"name": i, "id": i} for i in df.columns],
#             data=df.to_dict("records"),
#             style_table={'overflowX': 'auto', 'borderRadius': '5px'},
#             style_cell={"textAlign": "center", 'fontSize': '12px'},
#             style_header={"backgroundColor": "#4682B4", "color": "white", "fontWeight": "bold"},
#             style_data_conditional=[
#                 {'if': {'filter_query': '{Status} = "NOT OK"'}, 'backgroundColor': '#F5B7B1', 'color': '#C0392B', 'fontWeight': 'bold'},
#                 {'if': {'filter_query': '{Status} = "OK"'}, 'backgroundColor': '#D4EDDA', 'color': '#155724'},
#             ]
#         )
#     except Exception as e:
#         error_info = html.Div([
#             html.P("Error loading samples:", className="text-danger"),
#             html.Pre(str(e))
#         ])
#         print(f"Error in load_samples: {traceback.format_exc()}")
#         return error_info


# # ---------------------------
# # RUN APP
# # ---------------------------

# if __name__ == "__main__":
#     app.run(debug=True, port=8050)





import dash
from dash import html, dcc, Input, Output, State, dash_table
import dash_bootstrap_components as dbc
import pandas as pd
from datetime import datetime, date 
import traceback
from sqlalchemy.orm import joinedload 

# NOTE: These imports rely on Database.py and Database_models.py being accessible.
from Database import session
from Database_models import (
    QRRecord_Generated,
    SubContract_Inspection,
    DimensionReport,
    DimensionSample,
    DimensionCommonReport,
    DimensionType,
    Measuring_Instruments_Used, # NEW: Import the linking table
    Measuring_Instruments # NEW: Import the instrument details table
)

# ---------------------------
# DB FETCH FUNCTIONS
# ---------------------------

def get_refs_from_db():
    """Fetches all Reference Numbers available in the generated records."""
    db = session()
    try:
        refs = db.query(QRRecord_Generated.Reference_No).all()
        return sorted([r[0] for r in refs])
    except Exception as e:
        print(f"Error fetching references: {e}")
        return []
    finally:
        db.close()

def get_qr_record(ref_no):
    """Fetches the main QR record (source data)."""
    db = session()
    try:
        return db.query(QRRecord_Generated).filter_by(Reference_No=ref_no).first()
    finally:
        db.close()

def get_subcontract(ref_no):
    """Fetches the Subcontract Inspection report."""
    db = session()
    try:
        return db.query(SubContract_Inspection).filter_by(Reference_No=ref_no).first()
    finally:
        db.close()

def get_dimension_common(ref_no):
    """Fetches the Common Dimension Report (Header data)."""
    db = session()
    try:
        # Assuming DimensionCommonReport exists and is linked
        return db.query(DimensionCommonReport).filter_by(Reference_No=ref_no).first()
    except Exception:
        # Handle case where the table/model might be missing or misconfigured
        return None
    finally:
        db.close()

def get_dimensions(ref_no):
    """
    Fetches all detailed Dimension Reports for a given Reference_No,
    FORCING the related DimensionType and Samples to load immediately (joinedload).
    """
    db = session()
    try:
        return (
            db.query(DimensionReport)
            .options(joinedload(DimensionReport.dimension_type),
                     joinedload(DimensionReport.samples))
            .filter(DimensionReport.Reference_No == ref_no)
            .all()
        )
    finally:
        db.close()

def get_instruments_used(ref_no):
    """Fetches the details of all measuring instruments used for the given Reference_No."""
    db = session()
    try:
        return (
            db.query(Measuring_Instruments)
            .join(Measuring_Instruments_Used, 
                  Measuring_Instruments.Equipment_ID == Measuring_Instruments_Used.Equipment_ID)
            .filter(Measuring_Instruments_Used.Reference_No == ref_no)
            .all()
        )
    finally:
        db.close()

# ---------------------------
# DASH APP LAYOUT & STYLES
# ---------------------------

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.PULSE, dbc.icons.FONT_AWESOME]) 
app.title = "Inspection Dashboard"

# Helper function to format attribute names nicely
def format_key(key):
    return key.replace('_', ' ').title().replace('No', 'No.').replace('Dt', 'Date').replace('ID', 'ID')

# Card generator for key-value pairs
def create_summary_block(title, data_object, fields):
    if not data_object:
        return html.P(f"No {title.lower()} data found.", className="text-muted fst-italic p-2")

    items = []
    for field in fields:
        value = getattr(data_object, field, None)
        if value is not None:
            
            if isinstance(value, (datetime, date)): 
                value = value.strftime("%Y-%m-%d")
            
            color_class = "text-secondary"
            icon = ""
            
            # Use icons and colors for status/inspection fields
            if "Inspection" in field or "Report" in field or "Material" in field or "Status" in field:
                 upper_value = str(value).upper()
                 if upper_value in ["OK", "ACCEPTED"]:
                    color_class = "text-success fw-bold"
                    icon = html.I(className="fa-solid fa-check-circle me-2")
                 elif upper_value in ["NOT OK", "REJECTED"]:
                    color_class = "text-danger fw-bold"
                    icon = html.I(className="fa-solid fa-times-circle me-2")
                 elif upper_value in ["PENDING", "N/A", "NONE"]:
                    color_class = "text-warning"
                    icon = html.I(className="fa-solid fa-hourglass-half me-2")
                 else:
                     color_class = "text-dark" # Default for descriptive text

            items.append(
                dbc.Row([
                    dbc.Col(html.B(f"{format_key(field)}:"), width=5, className="text-dark fw-medium"),
                    dbc.Col(html.Div([icon, str(value)], className=color_class)),
                ], className="g-0 border-bottom border-light py-2 px-1")
            )
    return html.Div(items, className="p-1")

# Component to display the instruments used (NEW)
def create_instrument_table(instruments):
    if not instruments:
        return html.P("No measuring instruments recorded for this inspection.", className="text-muted p-2")

    df = pd.DataFrame([
        {
            "ID": i.Equipment_ID,
            "Description": i.Description,
            "Make/Model": i.Make_Model,
            "Accuracy": i.Measuring_Accuracy,
            "Calibration Due": i.Due_Date.strftime("%Y-%m-%d") if i.Due_Date else 'N/A'
        } for i in instruments
    ])

    return dash_table.DataTable(
        columns=[{"name": format_key(i), "id": i} for i in df.columns],
        data=df.to_dict("records"),
        style_table={'overflowX': 'auto', 'borderRadius': '8px', 'border': '1px solid #ddd'},
        style_cell={"textAlign": "center", 'padding': '10px', 'fontSize': '12px', 'border': 'none', 'color': '#333'},
        style_header={"backgroundColor": "#5D6D7E", "color": "white", "fontWeight": "bold", 'fontSize': '13px'},
        style_data_conditional=[
            {'if': {'filter_query': '{Calibration Due} = "N/A"'}, 'backgroundColor': '#f9f9f9'},
        ]
    )

# Component to display the samples for all dimensions
def create_samples_display(dims):
    if not dims:
        return html.P("No dimension samples recorded.", className="text-muted p-2")

    all_sample_data = []
    
    for d in dims:
        dimension_name = d.dimension_type.Name if d.dimension_type else f"Report ID {d.Id}"
        min_val = d.Min
        max_val = d.Max
        
        for s in d.samples:
            all_sample_data.append({
                "Dimension": dimension_name,
                "Basic/Tol": f"{d.Basic_Dimension} ±{d.Tolerance}",
                "Sample No.": s.Sample_No,
                "Value": s.Value,
                "Unit": s.Dimension_Parameter_Unit,
                "Status": s.Status,
                "Remarks": s.Remarks or "N/A",
                "Min": min_val,
                "Max": max_val
            })

    if not all_sample_data:
        return html.P("No samples found within the fetched dimension reports.", className="text-muted p-2")

    df = pd.DataFrame(all_sample_data)
    
    display_columns = ["Dimension", "Sample No.", "Value", "Unit", "Status", "Basic/Tol", "Min", "Max", "Remarks"]

    return dash_table.DataTable(
        columns=[{"name": format_key(i), "id": i} for i in display_columns],
        data=df.to_dict("records"),
        style_table={'overflowX': 'auto', 'borderRadius': '8px', 'border': '1px solid #ddd'},
        style_cell={"textAlign": "center", 'padding': '10px', 'fontSize': '12px', 'border': 'none', 'color': '#333'},
        style_header={"backgroundColor": "#34495E", "color": "white", "fontWeight": "bold", 'fontSize': '13px', 'border': 'none', 'border-bottom': '3px solid #1abc9c'},
        style_data_conditional=[
            {'if': {'filter_query': '{Status} = "NOT OK"'}, 'backgroundColor': '#FDEAEA', 'color': '#C0392B', 'fontWeight': 'bold'},
            {'if': {'filter_query': '{Status} = "OK"'}, 'backgroundColor': '#EBF5FB', 'color': '#2C3E50'},
            {'if': {'column_id': 'Status'}, 'fontWeight': 'bold'},
        ]
    )


app.layout = dbc.Container(
    [
        html.H2("Component Inspection Data Viewer", className="text-center my-4 text-primary", style={'fontWeight': 800}),

        # 1. Dropdown Row (Distinct Header)
        dbc.Row(
            dbc.Col(
                dbc.Card(
                    [
                        dbc.CardHeader([html.I(className="fa-solid fa-search me-2"), "Select Reference Number"], className="bg-dark text-white fw-bold"),
                        dbc.CardBody(
                            [
                                dcc.Dropdown(
                                    id="ref-dropdown",
                                    options=[{"label": r, "value": r} for r in get_refs_from_db()],
                                    clearable=True,
                                    placeholder="Choose Reference_No to load full inspection details",
                                    className="mb-2"
                                ),
                                html.Small(id="ref-last-loaded", className="text-muted d-block text-center pt-2")
                            ]
                        ),
                    ], className="shadow-lg mb-4 border-primary"
                ),
                width={"size": 8, "offset": 2},
            )
        ),

        html.Hr(className="my-4"),

        dbc.Row(
            [
                # Left column (Summary Blocks)
                dbc.Col(
                    [
                        # QR Record Summary
                        dbc.Card(
                            [
                                dbc.CardHeader([html.I(className="fa-solid fa-box me-2"), "Source QR Record & Logistics"], className="bg-light fw-bold text-dark"),
                                dbc.CardBody(html.Div(id="qr-summary")),
                            ],
                            className="mb-4 shadow-sm border-start border-3 border-info",
                        ),

                        # Subcontract Summary
                        dbc.Card(
                            [
                                dbc.CardHeader([html.I(className="fa-solid fa-clipboard-check me-2"), "Subcontract Inspection Status"], className="bg-light fw-bold text-dark"),
                                dbc.CardBody(html.Div(id="subcontract-summary")),
                            ],
                            className="mb-4 shadow-sm border-start border-3 border-success",
                        ),
                        
                        # Common Dimension Info
                        dbc.Card(
                            [
                                dbc.CardHeader([html.I(className="fa-solid fa-cogs me-2"), "Common Dimensional/Electrical Checks"], className="bg-light fw-bold text-dark"),
                                dbc.CardBody(html.Div(id="common-dim")),
                            ],
                            className="mb-4 shadow-sm border-start border-3 border-warning",
                        ),
                        
                        # NEW: Measuring Instruments Used
                        dbc.Card(
                            [
                                dbc.CardHeader([html.I(className="fa-solid fa-tools me-2"), "Measuring Instruments Used"], className="bg-light fw-bold text-dark"),
                                dbc.CardBody(html.Div(id="instruments-used-table")),
                            ],
                            className="mb-4 shadow-sm border-start border-3 border-secondary",
                        ),
                        
                    ],
                    width=4,
                ),

                # Right column (Dimension Details)
                dbc.Col(
                    [
                        dbc.Card(
                            [
                                dbc.CardHeader([html.I(className="fa-solid fa-chart-bar me-2"), "Dimension Measurement Analysis"], className="bg-primary text-white fw-bold"),
                                dbc.CardBody(
                                    [
                                        html.H5("Dimension Overview (Basic Specs)", className="text-secondary mb-3"),
                                        # Dimension Report Table (Overview)
                                        html.Div(id="dimension-table", className="mb-4"),
                                        
                                        html.Hr(),

                                        html.H5("All Measured Samples (Raw Data)", className="text-secondary mt-4"),
                                        # Combined Samples Table
                                        html.Div(id="samples-table"),
                                    ]
                                ),
                            ], className="shadow-lg"
                        )
                    ],
                    width=8,
                ),
            ]
        ),
    ],
    fluid=True,
)

# ---------------------------
# CALLBACK – WHEN REF SELECTED (COMBINED DATA LOAD)
# ---------------------------

@app.callback(
    [
        Output("qr-summary", "children"),
        Output("subcontract-summary", "children"),
        Output("common-dim", "children"),
        Output("dimension-table", "children"),
        Output("samples-table", "children"), 
        Output("instruments-used-table", "children"), # NEW: Output for instrument table
        Output("ref-last-loaded", "children"),
    ],
    Input("ref-dropdown", "value"),
)
def load_reference_data(ref):
    if not ref:
        empty_message = html.P("Select a Reference Number above to view details.")
        # Returning 7 elements: 5 summaries + 1 table + 1 status message
        return [empty_message] * 6 + [""]

    try:
        # --- Fetch all data ---
        qr = get_qr_record(ref)
        subcontract = get_subcontract(ref)
        common = get_dimension_common(ref)
        dims = get_dimensions(ref) 
        instruments = get_instruments_used(ref) # NEW: Fetch instruments

        # --- 1. QR Summary ---
        qr_fields = ["BEL_Part_Number", "MPN", "Vendor_Name", "Quantity", "GR_No", "Invoice_No", "GR_Date", "Description"]
        qr_block = create_summary_block("QR Record", qr, qr_fields)

        # --- 2. Subcontract Summary ---
        sc_fields = ["SAN_NO", "Control_No", "PO_NO", "Sample", "Drg_Issue_Level", 
                     "Visual_Inspection", "Vendor_Dimension_Report", "Raw_Material_Supplied", "Raw_Material_Test_Report"]
        sc_block = create_summary_block("Subcontract", subcontract, sc_fields)

        # --- 3. Common Dimension Info (Custom fields for clarity) ---
        common_fields = ["Dimension_Remark", "Electrical_Inspection_Remark", "Visual_Inspection_Report",
                         "Qty_Received", "Qty_Inspected", "Qty_Accepted", "Inspection_Remarks"]
        common_items = create_summary_block("Common Dimension", common, common_fields)

        # --- 4. Dimension Reports Table (Overview) ---
        if dims:
            df = pd.DataFrame(
                [
                    {
                        "Dimension": d.dimension_type.Name if d.dimension_type else "N/A", 
                        "Basic Dim.": d.Basic_Dimension,
                        "Tolerance": d.Tolerance,
                        "Min Value": d.Min,
                        "Max Value": d.Max,
                        "Report_Id": d.Id, # Keep ID for reference
                    }
                    for d in dims
                ]
            )
            dim_table = dash_table.DataTable(
                columns=[{"name": format_key(i), "id": i} for i in df.columns],
                data=df.to_dict("records"),
                style_table={'overflowX': 'auto', 'borderRadius': '5px'},
                style_cell={"textAlign": "center", "padding": "8px", 'fontSize': '12px'},
                style_header={"backgroundColor": "#4682B4", "color": "white", "fontWeight": "bold", 'fontSize': '13px'},
                id="dimension-report-table-output"
            )
        else:
            dim_table = html.P("No detailed dimensions defined for this reference.", className="text-warning p-2")

        # --- 5. Combined Samples Table ---
        samples_table = create_samples_display(dims)
        
        # --- 6. Instrument Used Table ---
        instrument_table = create_instrument_table(instruments)

        # --- 7. Return values (7 total outputs) ---
        return (
            qr_block,
            sc_block,
            common_items,
            dim_table,
            samples_table,
            instrument_table, # NEW: Added instrument table output
            f"Last loaded: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        )
    except Exception as e:
        error_info = html.Div([
            html.P("An unexpected error occurred while fetching data:", className="text-danger"),
            html.Pre(traceback.format_exc())
        ])
        print(f"Error in load_reference_data: {traceback.format_exc()}")
        # Ensure 7 outputs are returned on error
        return [error_info] * 6 + [f"Error at {datetime.now().strftime('%H:%M:%S')}"]


# ---------------------------
# RUN APP
# ---------------------------

if __name__ == "__main__":
    app.run(debug=True, port=8050)