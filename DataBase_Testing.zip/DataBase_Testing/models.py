# from pydantic import BaseModel
# from datetime import datetime
# class Data(BaseModel):
#     division:str
#     part_no: int 
#     item_no: int 
#     description: str
#     quantity: int 
#     po_number: int
#     name: str
#     staff_no: int
#     date: datetime
#     comments:str
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import pandas as pd
class QRRecord(BaseModel):
    Timestamp: Optional[datetime]
    SL_No: Optional[int]
    BEL_Part_Number: Optional[int]
    MPN: Optional[str]
    Batch_Lot_No: Optional[str]
    DateCode: Optional[int]
    Quantity: Optional[int]
    BEL_PO_No: Optional[str]
    Vendor_Name: Optional[str]
    OEM_Make: Optional[str]
    Manufacturing_Place: Optional[str]
    GR_No: Optional[str]
    GR_Date: Optional[datetime]
    Reference_No: Optional[str]
    Description : Optional[str]
    Vendor_Code : Optional[str]
    Invoice_No  : Optional[str]
    Invoice_Dt : Optional[datetime]
    Status : Optional[str]

    @classmethod
    def from_csv(cls, csv_file: str):
        import pandas as pd
        df = pd.read_csv(csv_file)
        records = []
        for _, row in df.iterrows():
            # Convert date strings to datetime
            row_dict = row.to_dict()
            if "Timestamp" in row_dict and row_dict["Timestamp"]:
                try:
                    row_dict["Timestamp"] = datetime.strptime(row_dict["Timestamp"], "%Y-%m-%d %H:%M:%S")
                except:
                    row_dict["Timestamp"] = None
            if "GR_Date" in row_dict and row_dict["GR_Date"]:
                try:
                    row_dict["GR_Date"] = datetime.strptime(row_dict["GR_Date"], "%Y-%m-%d")
                except:
                    row_dict["GR_Date"] = None
            records.append(cls(**row_dict))
        return records 

# class UserCreate(BaseModel):
#     username: str
#     email: str
#     password: str   # plaintext from user

# class UserOut(BaseModel):
#     id: int
#     username: str
#     email: str

#     class Config:
#         orm_mode = True
# class QRRecord(BaseModel):
#     Timestamp: Optional[datetime]
#     SL_No: Optional[int]
#     BEL_Part_Number: Optional[int]
#     MPN: Optional[str]
#     Batch_Lot_No: Optional[str]
#     DateCode: Optional[int]
#     Quantity: Optional[int]
#     BEL_PO_No: Optional[str]
#     Vendor_Name: Optional[str]
#     OEM_Make: Optional[str]
#     Manufacturing_Place: Optional[str]
#     GR_No: Optional[str] = None
#     GR_Date: Optional[datetime] = None
#     Reference_No: Optional[str] = None

#     @classmethod
#     def from_csv(cls, csv_file: str):
#         import pandas as pd
#         from datetime import datetime

#         df = pd.read_csv(csv_file)
#         df.columns = df.columns.str.strip()

#         # Replace NaN with None
#         df = df.where(pd.notnull(df), None)

#         # Convert numeric columns to int safely
#         for col in ["SL_No", "BEL_Part_Number", "DateCode", "Quantity"]:
#             if col in df.columns:
#                 df[col] = df[col].apply(lambda x: int(x) if x is not None else None)

#         # Convert date columns safely
#         for col in ["Timestamp", "GR_Date"]:
#             if col in df.columns:
#                 df[col] = pd.to_datetime(df[col], errors="coerce")

#         # Convert GR_No and Reference_No safely
#         for col in ["GR_No", "Reference_No"]:
#             if col in df.columns:
#                 df[col] = df[col].apply(lambda x: str(x) if x is not None else None)
#                 df[col] = df[col].apply(lambda x: None if x == 'nan' else x)

#         # Build Pydantic models
#         records = [cls(**row) for row in df.to_dict(orient="records")]
#         return records

class SubContract_Inspection_Report(BaseModel):
    Control_No: Optional[int]
    SAN_NO : Optional[int]
    Part_No : Optional[str]
    Description : Optional[str]
    PO_NO : Optional[str]
    Vendor_Name : Optional[str]
    Quantity : Optional[str]
    Sample: Optional[str]
    Sale_Order : Optional[str]
    Drg_Issue_Level : Optional[int]
    Reference_No :Optional[str]
    Date :Optional[datetime]
    Vendor_Dimension_Report : Optional[str]
    Visual_Inspection : Optional[str]
    Raw_Material_Supplied : Optional[str]
    Raw_Material_Test_Report : Optional[str]



    